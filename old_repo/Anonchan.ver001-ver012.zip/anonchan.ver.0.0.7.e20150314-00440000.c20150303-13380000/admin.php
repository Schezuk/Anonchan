<?php
# EXECUTE INIT
require './init.php';
$ID = intval($_REQUEST['id']);
if ($ID < 1 || $ID >= MAX_THREAD_ID) die(enjson(array('success'=>false, 'request'=>'admin','message'=>'invalid id')));
try {
    $pdo = new PDO($dsn, $username, $password,$options);
    switch (strtolower(trim($_REQUEST['action']))){
        case 'delete'   : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `delete` = `delete` + 1 WHERE `id` = $ID;"); break;
        case 'undelete' : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `delete` = (CASE WHEN `delete` > 0 THEN `delete` - 1 ELSE 0 END) WHERE `id` = $ID;"); break;
        case 'sage'     : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `sage`   = `sage`   + 1 WHERE `id` = $ID;"); break;
        case 'unsage'   : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `sage`   = (CASE WHEN `sage`   > 0 THEN `sage`   - 1 ELSE 0 END) WHERE `id` = $ID;"); break;
        case 'lock'     : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `lock`   = `lock`   + 1 WHERE `id` = $ID;"); break;
        case 'unlock'   : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `lock`   = (CASE WHEN `lock`   > 0 THEN `lock`   - 1 ELSE 0 END) WHERE `id` = $ID;"); break;
        case 'hide'     : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `hide`   = `hide`   + 1 WHERE `id` = $ID;"); break;
        case 'unhide'   : $rc = $pdo->query("UPDATE `{$TABLE_NAME}` SET `hide`   = (CASE WHEN `hide`   > 0 THEN `hide`   - 1 ELSE 0 END) WHERE `id` = $ID;"); break;
        case 'edit'     : $rc = $pdo->query(
            "UPDATE `{$TABLE_NAME}` SET `content`= CONCAT(CONCAT(CONCAT('name: ', `name`),CONCAT('<br />content: ', `content`)), CONCAT(CONCAT('<br />edit time:','"
             . date("Y-m-d H:i:s") 
             . "'), CONCAT('<br /><hr />', '" 
             . strval($_REQUEST['content']) . 
             "'))), `name` = '<b><div style=\"color=#FF0000\">ADMIN</div>' WHERE `id` = $ID;"
        );break;
        default: die(enjson(array('success'=>false, 'request'=>'admin','message'=>'invalid action')));
    }
    exit (enjson(array('success'=>false, 'request'=>'admin','message'=>'Check it yourself. Ain\'t you an admin, huh?')));
} catch (PDOException $pdoException){
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'delete';
    $done['code'   ] = $pdoException->getCode();
    $done['line'   ] = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
    # EXECUTE DONE 
    require './tpl/done.php';
    exit;
}
