<?php
################################################################################
# Configuration File. Please save it in UNIX UTF-8(no BOM).                    #
# ============================================================================ #
# Database Configuration                                                       #
# ---------------------------------------------------------------------------- #
$DB_TYPE           =           'mysql'; # Database Type                        #
$DB_NAME           = 'database`s name'; # Database Name                        #
$DB_HOST           =       'localhost'; # Database Address                     #
$DB_PORT           =              3306; # Database Port                        #
$DB_USER           =        'username'; # Database Username                    #
$DB_PSWD           =        'password'; # Database Password                    #
# ============================================================================ #
# Board Configuation                                                           #
# ---------------------------------------------------------------------------- #
$LANGUAGE          =           'zh-CN'; # Board Language Setting               #
$TABLE_NAME        =          'sougou'; # Name of the Table Used in Database   #
$FORUM_NAME        =          'Random'; # Name of the Forum                    #
$BOARD_NAME        =        'Anonchan'; # Name of the Board                    #
$TRIPCODE_SALT     =    'YW5vbmNoYW4='; # Salt in the Tripcode                 #
$ADMIN_PASSWORD    = strval(mt_rand()); # Password of the Administrator        #
# ---------------------------------------------------------------------------- #
# During installation, change $TRIPCODE_SALT to any string *ONCE AND FOR ALL*. #
# If you want to make someone admin, specify the key as a string and share it. #
# ============================================================================ #
# Forum Configuation                                                           #
# ---------------------------------------------------------------------------- #
$COOL_DOWN          = 30;# Minimum duration(second) between posting 2 threads. #
$REFRESH_DURATION   =  5;# Duration before refreshing after posting or erring. #
$REPLIES_PER_PAGE   = 20;# Recommended. Higher value may make your server lag. #
$THREADS_PER_PAGE   = 20;# Recommended. Higher value may make your server lag. #
$RECENT_REPLIES     =  5;# Recommended. An interger value ranged from 0 to 20. #
$BLACK_LIST[]='00000000';# Examples of black list. It forbids people to reply. #
$BLACK_LIST[]='AAAAAAAA';# Black list containing 8-digit UIDs of whom you ban. #
$BLACK_LIST[]='ZZZZZZZZ';# You may add as many tripcodes of uid as you'd like. #
$SHOW_LIKER      = 'all';# Amount of UID's of recent likers/dislikers to show. #
$SHOW_DISLIKER   = 'all';# -1: Hide amount/UID's; 0: Hide UID; 'all':Show all. #
$HIDE_RATIO         =  1;# Reply will hide, when dislikers *OUTNUMBER* likers. #
$HIDE_DIVIATION     =  5;# I.e., DISLIKE > HIDE_RATIO * LIKE + HIDE_DIVIATION. #
$WEB_ANALYTICS = 'Here quotes the code of your Web-analytics Service Provider.';
# ---------------------------------------------------------------------------- #
# If the code is consisted of multiple lines. Just join them into single line. #
# ============================================================================ #
# THIS IS THE END OF THE CONFIGURATION FILE. DON'T ADD '?' AND '>' AT THE END. #
################################################################################