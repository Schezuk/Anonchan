<!--template.tail.php-->
<hr />
<div id="del">
	<form action="./delete.php" method="post" enctype="multipart/form-data" onsubmit="return check_reply();" id="postform_main">
		<table style="float: right;">
			<tr>
				<td align="center" style="white-space: nowrap;"><?php echo $__delete_post; ?></td>
				<td><?php echo $__post_reply_id; ?></td>
				<td>
					<input type="text" name="id" id="fid" size="10" maxlength="10" value=""/>
				</td>
				<td><?php echo $__pwd_to_delete; ?></td>
				<td>
					<input type="password" name="pwd" id="fpwd" size="8" maxlength="8" value=""/>
				</td>
				<td>
					[<input type="checkbox" name="onlyimgdel" id="onlyimgdel" value="on" /><label for="onlyimgdel"><?php echo $__onlyimgdel; ?></label>]
				</td>
				<td>
					<input type="submit" value="<?php echo $__del_execute; ?>" />
				</td>
	        	</tr>
		</table>
	</form>
</div>
<script type="text/javascript">delpost();</script>
<div id="page_switch">
	<div>
		[<a class="prev" href="<?php echo $INFO['url']; ?>?page=1"><?php echo $__first_page; ?></a>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page-4; if(0<$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page-3; if(0<$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page-2; if(0<$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page-1; if(0<$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		}?>
		[<span class="current"><?php echo $page; ?></span>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page+1; if($size>=$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page+2; if($size>=$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page+3; if($size>=$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		$page_switch=$page+4; if($size>=$page_switch) echo "[<a class=\"num\" href=\"{$INFO['url']}page={$page_switch}\">{$page_switch}</a>]";
		}?>
		[<a class="end" href="<?php echo $INFO['url']; ?>?page=<?php echo $INFO['size']; ?>"><?php echo $__last_page; ?></a>]
	</div>
</div>
<div id="footer">
	<script type="text/javascript">preset();</script>
	<!--Space for Web Analytics Service.-->
	<?php echo $WEB_ANALYTICS; ?>
	<!--End of space for Web Analytics Service.-->
</div>
</body>
</html>
<!--end of template.tail.php-->
