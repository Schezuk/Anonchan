<!--template.reply.php-->
<div class="reply" id="<?php echo $REPLY['id']; ?>"><div class="replywrap">
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='<?php echo $REPLY['id']; ?>'; else $_('fid').value='';" />
	<?php if ( $REPLY['image']!=='') {?>
	<img src="<?php echo $REPLY['image']; ?>" class='img' style='max-width:250px; max-height:250px' />";
	<?php } ?>
	<span class="title"><?php if ($REPLY['title']=='') echo $__no_title; else echo $REPLY['title']; ?></span>
	<span class="name" ><?php if ($REPLY['name'] =='') echo $__no_name;  else echo $REPLY['name'];  ?></span>
	<span class="email" ><?php echo $REPLY['email'];  ?></span>
	<span class="time" ><?php echo date('Y-m-d H:i:s', $REPLY['createdAt']); ?></span>
	<span class="uid">[ID:<?php echo $REPLY['uid']; ?>]</span>
	<a href="<?php
		 if ('thread' == $INFO['type']) echo 'javascript:quote(', $REPLY['id'], ')'; 
		 if ('forum'  == $INFO['type']) echo './thread.php?id=', $REPLY['parent'], '#', $REPLY['id'];
		 ?>" class="qlink">No.<?php echo $REPLY['id']; ?></a>
	<br />
	<?php if ($REPLY['hide'] > 0) {?>
	<DIV style="cursor:hand" onclick="isHidden('h<?php $REPLY['id'];?>')"><?php $REPLY['$__isHidden'];?></DIV>
	<div class="quote" id="h<?php echo $REPLY['id']; ?>" style="display:none;">
    <?php } else {?>
    <div class="quote" id="h<?php echo $REPLY['id']; ?>" >
    <?php } echo $REPLY['content']; ?></div>
	<div class="like"><?php echo str_replace('####', $REPLY['like'], $__like); ?></div>
	<div class="liker"><?php if ($SHOW_LIKER > 0) echo $__show_them,$REPLY['liker']; ?></div>
	<div class="dislike"><?php echo str_replace('####', $REPLY['dislike'], $__dislike); ?></div>
	<div class="disliker"><?php if ($SHOW_DISLIKER > 0) echo $__show_them,$REPLY['disliker']; ?></div>
</div></div>
<!--end of template.reply.php-->
