<?php
if (isset($_REQUEST['callback'])) {
    $json_str = enjson(array(
        'info' => $INFO,
        'threads' => $THREADS,
        'replies' => $REPLIES
    ));
    $callback = preg_replace('/[^\w\$]/', '', $_REQUEST['callback']);
    echo "/**/ typeof {$callback} === \'function\' && {$callback}({$json_str})";
    exit;
} elseif (isset($_REQUEST['json'])) {
    $json_str = enjson(array(
        'info' => $INFO,
        'threads' => $THREADS,
        'replies' => $REPLIES
    ));
    echo $json_str;
    exit;
} else {
    header('Access-Control-Allow-Origin: *'); 
    header('Cache-Control: no-store, no-cache, must-revalidate');  
    header('Cache-Control: post-check=0, pre-check=0', false);  
    header('Pragma: no-cache');
    if (isset($_SERVER['HTTP_REFERER'])){
        header('refresh:' . $REFRESH_DURATION . ';url=' . $_SERVER['HTTP_REFERER']);
    } else {
        header('refresh:' . $REFRESH_DURATION . ';url=' . './forum.php');
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo ($done['success']) ? ($done['request'] . 'success') : ($done['request'] . 'falure'); ?></title>
    <style type="text/css">
        *{ padding: 0; margin: 0; }
        body{ background: #fff; font-family: '΢ɭ҅ºا; color: #333; font-size: 16px; }
        .system-message{ padding: 24px 48px; }
        .system-message h1{ font-size: 100px; font-weight: normal; line-height: 120px; margin-bottom: 12px; }
        .system-message .jump{ padding-top: 10px}
        .system-message .jump a{ color: #333;}
        .system-message .success,.system-message .error{ line-height: 1.8em; font-size: 36px }
        .system-message .detail{ font-size: 12px; line-height: 20px; margin-top: 12px; display:none}
    </style>
</head>
<body>
    <div class="system-message">
        <?php
            if ($done['success']){
        ?>
        <h1>:)</h1>
        <p class="success">Succeeded!</p>
        <?php
            } else{
        ?>
        <h1>:(</h1>
        <p class="error">Failed!</p> 
        <p class="detail">
        <?php 
                echo "Request: {$done['request']}<br />Status: Failed<br />Error Code: {$done['code']}<br />Error Line: {$done['line']}<br />Error Message: {$done['message']}";
            }
        ?>
        </p>
    </div>
</body>
</html>
<?php } ?>