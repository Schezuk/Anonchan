<?php
$ADMIN_PASSWORD	 = 'hahahaha';//YOU MUST CHANGE IT TO A STRING!!!
//start up
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  

if (1 > ($id=intval($_REQUEST['id'])))		die(json_err('id',1,'invalid thread id'));
switch ($_REQUEST['action']){
	case 'delete': safe_query("UPDATE `$TABLE_NAME` SET `delete` = '' WHERE `id` = ?;", &$blackhole, array('i',$id));break;
	case 'sage': safe_query("UPDATE `$TABLE_NAME` SET `sage` = '' WHERE `id` = ?;", &$blackhole, array('i',$id));break;
	case 'lock': safe_query("UPDATE `$TABLE_NAME` SET `lock` = '' WHERE `id` = ?;", &$blackhole, array('i',$id));break;
	case 'hide': safe_query("UPDATE `$TABLE_NAME` SET `hide` = '' WHERE `id` = ?;", &$blackhole, array('i',$id));break;
	case 'edit': safe_query("UPDATE `$TABLE_NAME` SET 
		`content` = CONCAT('ID:', CONCAT(`name`, CONCAT('<br />',CONCAT(`content`,CONCAT('<br />', ?))))),
		`name` = '<b><div style=\"color=#FF0000\">ADMIN</div>'
		 WHERE `id` = ?;", &$blackhole, array('si',$_REQUEST['content'],$id));break;
	default;
}
echo 'Check it yourself. Ain\'t you an admin, huh?';
?>