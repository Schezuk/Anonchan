<!--template.delpost.php-->
<hr />
<div id="del">
	<form action="/delete.php" method="post" enctype="multipart/form-data" onsubmit="return check_reply();" id="postform_main">
		<table style="float: right;">
			<tr>
				<td align="center" style="white-space: nowrap;">【删除文章】</td>
				<td>文章/回复ID</td>
				<td>
					<input type="text" name="id" id="fid" size="10" maxlength="10" value=""/>
				</td>
				<td>删除用密码:</td>
				<td>
					<input type="password" name="pwd" id="fpwd" size="8" maxlength="8" value=""/>
				</td>
				<td>
					[<input type="checkbox" name="onlyimgdel" id="onlyimgdel" value="on" /><label for="onlyimgdel">仅删除附加图片</label>]
				</td>
				<td>
					<input type="submit" value=" 执行 " />
				</td>
	        	</tr>
		</table>
	</form>
</div>
<script type="text/javascript">delpost();</script>
<!--end of template.delpost.php-->
