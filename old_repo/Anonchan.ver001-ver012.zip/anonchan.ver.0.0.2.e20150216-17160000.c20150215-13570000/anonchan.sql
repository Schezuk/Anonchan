-- phpMyAdmin SQL Dump
-- version 3.5.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 02 月 16 日 08:33
-- 服务器版本: 5.1.33-community
-- PHP 版本: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `zjwdb_290659`
--

-- --------------------------------------------------------

--
-- 表的结构 `anonchan`
--

CREATE TABLE IF NOT EXISTS `anonchan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `updatedAt` int(11) NOT NULL,
  `createdAt` int(11) NOT NULL,

  `pwd` char(8) NOT NULL,
  `like` int(11) NOT NULL,
  `dislike` int(11) NOT NULL,

  `hide` tinyint(1) NOT NULL,
  `sage` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL,
  `delete` tinyint(1) NOT NULL,

  `uid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` varchar(2048) NOT NULL,

  `replyCount` int(11) NOT NULL,
  `recentReply0` int(11) NOT NULL,
  `recentReply1` int(11) NOT NULL,
  `recentReply2` int(11) NOT NULL,
  `recentReply3` int(11) NOT NULL,
  `recentReply4` int(11) NOT NULL,
  `recentReply5` int(11) NOT NULL,
  `recentReply6` int(11) NOT NULL,
  `recentReply7` int(11) NOT NULL,
  `recentReply8` int(11) NOT NULL,
  `recentReply9` int(11) NOT NULL,

  PRIMARY KEY (`id`),
  KEY `updatedAt` (`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `anonchan`
--

INSERT INTO `anonchan` (`id`, `parent`, `updatedAt`, `createdAt`, 
  `pwd`, `like`, `dislike`, `hide`, `sage`, `lock`, `deleted`, 
  `uid`, `name`, `email`, `title`, `image`, `content`, `replyCount`, 
  `recentReply0`, `recentReply1`, `recentReply2`, `recentReply3`, `recentReply4`, 
  `recentReply5`, `recentReply6`, `recentReply7`, `recentReply8`, `recentReply9`
) VALUES (
  0, 0, 0, 0, 
  '00000000', 0, 0, 0, 1, 0, 1,
  0, '', '', '', '', '', 0,
  0, 0, 0, 0, 0,
  0, 0, 0, 0, 0
);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
