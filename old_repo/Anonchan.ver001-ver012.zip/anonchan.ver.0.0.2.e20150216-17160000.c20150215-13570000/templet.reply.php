<!--template.reply.php-->
<div class="reply" id="<?php echo $id; ?>"><div class="replywrap">
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='<?php echo $id; ?>'; else $_('fid').value='';" />
	<?php if ($image=='') echo '<!--'; ?>
	<img src="<?php echo $image; ?>" class="img" style="max-width:250px; max-height:250px" />
	<?php if ($image=='') echo '-->\r\n'; ?>
	<span class="title"><?php if ($title=='') echo '无标题'; else echo $title; ?></span>
	<span class="name" ><?php if ($name =='') echo '无名氏'; else echo $name;  ?></span>
	<span class="time" ><?php echo date('Y-m-d H:i:s', $createdAt); ?></span>
	<span class="uid">[ID:<?php echo $tripcode; ?>]</span>
	<a href="thread.php?id=<?php echo $id; ?>" class="qlink">No.<?php echo $id; ?></a>
	<br />
	<div class="quote"><?php echo $content; ?></div>
</div></div>
<!--end of template.reply.php-->
