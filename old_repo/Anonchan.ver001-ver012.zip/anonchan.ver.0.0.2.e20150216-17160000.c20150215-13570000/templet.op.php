<!--template.op.php-->
<hr/>
<div class="threadpost" id="<?php echo $id; ?>"> 
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='<?php echo $id; ?>'; else $_('fid').value='';" />
	<?php if ($image=='') echo '<!--'; ?>
	<img src="<?php echo $image; ?>" class="img" style="max-width:250px; max-height:250px" />
	<?php if ($image=='') echo '-->\r\n'; ?>
	<span class="title"><?php if ($title=='') echo '无标题'; else echo $title; ?></span>
	<span class="name" ><?php if ($name =='') echo '无名氏'; else echo $name;  ?></span>
	<span class="time" ><?php echo date('Y-m-d H:i:s', $createdAt); ?></span>
	<span class="uid">[ID:<?php echo $tripcode; ?>]</span>
	<a href="thread.php?id=<?php echo $id; ?>" class="qlink">No.<?php echo $id; ?></a>
	&nbsp;
	<a href="thread.php?id=<?php echo $id; ?>">[回复]</a>
	<br />
	<div class="quote"><?php echo $content; ?></div>
	<?php 
	if ($replycount > $recentreplycount) {
		echo '<br/><span class="warn_txt2">该帖有 ',$replycount-$recentreplycount;
		echo ' 篇回复被省略。要查看所有回复请点击回应链接。</span>';
	}
	?>

</div>
<!--end of template.op.php-->
