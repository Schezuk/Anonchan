<!--template.header.php-->
<body>
<div id="header">
    <div id="toplink">
        [<a href="forum.php?page=1" rel="_top">回首页</a>]
        [<a href="?">刷新</a>]
    </div>
    <br />
    <h1><?php echo $thread_title . $forum_title;?></h1>
    <hr class="top" />
</div>
<!--end of template.header.php-->
