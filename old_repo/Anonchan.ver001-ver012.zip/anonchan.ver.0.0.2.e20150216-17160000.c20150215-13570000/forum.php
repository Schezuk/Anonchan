<?php
require(lib.config.php);
require(lib.mysqli.php);
/* some mysql procedure */
$thread_title='';
//$forum_title='';
//$board_title='';
require('templet.head.php');
require('templet.header.php');
