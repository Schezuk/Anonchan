<?php
require(lib.config.php);
require(lib.mysqli.php);
/* some mysql procedure */
$thread_title='No.' . strval($thread_id) . ' - ';
//$forum_title='';
//$board_title='';
require('templet.head.php');
$thread_title='No.' . strval($thread_id);
$forum_title='';
//$board_title='';
require('templet.header.php');
