<!--template.tail.php-->
<div id="page_switch">
	<div>
		[<a class="prev" href="/forum.php?page=1">首页</a>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page-4; if(0<$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-3; if(0<$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-2; if(0<$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-1; if(0<$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		}?>
		[<span class="current"><?php echo $page; ?></span>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page+1; if($size>=$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+2; if($size>=$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+3; if($size>=$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+4; if($size>=$page_switch) echo "[<a class=\"num\" href=\"/forum.php?page=$page_switch\">$page_switch</a>]";
		}?>
		[<a class="end" href="/forum.php?page=<?php echo $size; ?>">末页</a>]
	</div>
</div>
<div id="footer">
	<script type="text/javascript">preset();</script>
	<!--以下空白留站长统计用，请自行定制。-->

	<!--以上空白留站长统计用，请自行定制。-->
</div>
</body>
</html>
<!--end of template.tail.php-->
