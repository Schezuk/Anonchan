<!--template.newpost.php-->
<script type="text/javascript">
window.onload = function() {
	var ds_textarea = document.getElementById("fcom");
	var faceList = ["|∀ﾟ", "(´ﾟДﾟ`)", "(;´Д`)", "(｀･ω･)", "(=ﾟωﾟ)=", "| ω・´)", "|-` )", "|д` )", "|ー` )", "|∀` )", "(つд⊂)", "(ﾟДﾟ≡ﾟДﾟ)", "(＾o＾)ﾉ", "(|||ﾟДﾟ)", "( ﾟ∀ﾟ)", "( ´∀`)", "(*´∀`)", "(*ﾟ∇ﾟ)", "(*ﾟーﾟ)", "(　ﾟ 3ﾟ)", "( ´ー`)", "( ・_ゝ・)", "( ´_ゝ`)", "(*´д`)", "(・ー・)", "(・∀・)", "(ゝ∀･)", "(〃∀〃)", "(*ﾟ∀ﾟ*)", "( ﾟ∀。)", "( `д´)", "(`ε´ )", "(`ヮ´ )", "σ`∀´)", " ﾟ∀ﾟ)σ", "ﾟ ∀ﾟ)ノ", "(╬ﾟдﾟ)", "(|||ﾟдﾟ)", "( ﾟдﾟ)", "Σ( ﾟдﾟ)", "( ;ﾟдﾟ)", "( ;´д`)", "(　д ) ﾟ ﾟ", "( ☉д⊙)", "(((　ﾟдﾟ)))", "( ` ・´)", "( ´д`)", "( -д-)", "(>д<)", "･ﾟ( ﾉд`ﾟ)", "( TдT)", "(￣∇￣)", "(￣3￣)", "(￣ｰ￣)", "(￣ . ￣)", "(￣皿￣)", "(￣艸￣)", "(￣︿￣)", "(￣︶￣)", "ヾ(´ωﾟ｀)", "(*´ω`*)", "(・ω・)", "( ´・ω)", "(｀・ω)", "(´・ω・`)", "(`・ω・´)", "( `_っ´)", "( `ー´)", "( ´_っ`)", "( ´ρ`)", "( ﾟωﾟ)", "(oﾟωﾟo)", "(　^ω^)", "(｡◕∀◕｡)", "/( ◕‿‿◕ )\\", "ヾ(´ε`ヾ)", "(ノﾟ∀ﾟ)ノ", "(σﾟдﾟ)σ", "(σﾟ∀ﾟ)σ", "|дﾟ )", "┃電柱┃", "ﾟ(つд`ﾟ)", "ﾟÅﾟ )　", "⊂彡☆))д`)", "⊂彡☆))д´)", "⊂彡☆))∀`)", "(´∀((☆ミつ"];
	var optionsList = document.getElementById("emotion").options;
	for (var i = 0; i < faceList.length; i++) {
		optionsList[1 + i] = new Option(faceList[i], faceList[i]);
	}
	document.getElementById("emotion").onchange = function(i) {
		if (this.selectedIndex != 0) {
			ds_textarea.value += this.value;
			//alert(this.value);
			var l = ds_textarea.value.length;
			ds_textarea.focus();
			ds_textarea.setSelectionRange(l, l);
		}
	}
}
</script>
<div id="postform" style="text-align: center;">
<form action="/post.php" method="post" enctype="multipart/form-data" onsubmit="return check_reply();" id="postform_main">
<table cellpadding="1" cellspacing="1" id="postform_tbl" style="margin: 0px auto; text-align: left;">
	<tr>
		<td class="Form_bg"><b>名　称</b></td>
		<td>
			<input type="text" name="name" id="fname" size="28" value=""/>
			<input type="submit" name="sendbtn" style="width: 80px;" value="送 出"/>
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>电　邮</b></td>
		<td>
			<input type="text" name="email" id="femail" size="28" value=""/>
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>标　题</b></td>
		<td>
			<input type="text" name="title" id="fsub" size="28" value=""/>
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>颜文字</b></td>
		<td>
			<select id='emotion'>
				<option value='' selected='selected'>颜文字</option>
				<option value='|∀ﾟ'>|∀ﾟ</option>
				<option value='(´ﾟДﾟ`)'>(´ﾟДﾟ`)</option>
				<option value='(;´Д`)'>(;´Д`)</option>
				<option value='(｀･ω･)'>(｀･ω･)</option>
				<option value='(=ﾟωﾟ)='>(=ﾟωﾟ)=</option>
				<option value='| ω・´)'>| ω・´)</option>
				<option value='|-` )'>|-` )</option>
				<option value='|д` )'>|д` )</option>
				<option value='|ー` )'>|ー` )</option>
				<option value='|∀` )'>|∀` )</option>
				<option value='(つд⊂)'>(つд⊂)</option>
				<option value='(ﾟДﾟ≡ﾟДﾟ)'>(ﾟДﾟ≡ﾟДﾟ)</option>
				<option value='(＾o＾)ﾉ'>(＾o＾)ﾉ</option>
				<option value='(|||ﾟДﾟ)'>(|||ﾟДﾟ)</option>
				<option value='( ﾟ∀ﾟ)'>( ﾟ∀ﾟ)</option>
				<option value='( ´∀`)'>( ´∀`)</option>
				<option value='(*´∀`)'>(*´∀`)</option>
				<option value='(*ﾟ∇ﾟ)'>(*ﾟ∇ﾟ)</option>
				<option value='(*ﾟーﾟ)'>(*ﾟーﾟ)</option>
				<option value='(　ﾟ 3ﾟ)'>(　ﾟ 3ﾟ)</option>
				<option value='( ´ー`)'>( ´ー`)</option>
				<option value='( ・_ゝ・)'>( ・_ゝ・)</option>
				<option value='( ´_ゝ`)'>( ´_ゝ`)</option>
				<option value='(*´д`)'>(*´д`)</option>
				<option value='(・ー・)'>(・ー・)</option>
				<option value='(・∀・)'>(・∀・)</option>
				<option value='(ゝ∀･)'>(ゝ∀･)</option>
				<option value='(〃∀〃)'>(〃∀〃)</option>
				<option value='(*ﾟ∀ﾟ*)'>(*ﾟ∀ﾟ*)</option>
				<option value='( ﾟ∀。)'>( ﾟ∀。)</option>
				<option value='( `д´)'>( `д´)</option>
				<option value='(`ε´ )'>(`ε´ )</option>
				<option value='(`ヮ´ )'>(`ヮ´ )</option>
				<option value='σ`∀´)'>σ`∀´)</option>
				<option value=' ﾟ∀ﾟ)σ'> ﾟ∀ﾟ)σ</option>
				<option value='ﾟ ∀ﾟ)ノ'>ﾟ ∀ﾟ)ノ</option>
				<option value='(╬ﾟдﾟ)'>(╬ﾟдﾟ)</option>
				<option value='(|||ﾟдﾟ)'>(|||ﾟдﾟ)</option>
				<option value='( ﾟдﾟ)'>( ﾟдﾟ)</option>
				<option value='Σ( ﾟдﾟ)'>Σ( ﾟдﾟ)</option>
				<option value='( ;ﾟдﾟ)'>( ;ﾟдﾟ)</option>
				<option value='( ;´д`)'>( ;´д`)</option>
				<option value='(　д ) ﾟ ﾟ'>(　д ) ﾟ ﾟ</option>
				<option value='( ☉д⊙)'>( ☉д⊙)</option>
				<option value='(((　ﾟдﾟ)))'>(((　ﾟдﾟ)))</option>
				<option value='( ` ・´)'>( ` ・´)</option>
				<option value='( ´д`)'>( ´д`)</option>
				<option value='( -д-)'>( -д-)</option>
				<option value='(&gt;д&lt;)'>(&gt;д&lt;)</option>
				<option value='･ﾟ( ﾉд`ﾟ)'>･ﾟ( ﾉд`ﾟ)</option>
				<option value='( TдT)'>( TдT)</option>
				<option value='(￣∇￣)'>(￣∇￣)</option>
				<option value='(￣3￣)'>(￣3￣)</option>
				<option value='(￣ｰ￣)'>(￣ｰ￣)</option>
				<option value='(￣ . ￣)'>(￣ . ￣)</option>
				<option value='(￣皿￣)'>(￣皿￣)</option>
				<option value='(￣艸￣)'>(￣艸￣)</option>
				<option value='(￣︿￣)'>(￣︿￣)</option>
				<option value='(￣︶￣)'>(￣︶￣)</option>
				<option value='ヾ(´ωﾟ｀)'>ヾ(´ωﾟ｀)</option>
				<option value='(*´ω`*)'>(*´ω`*)</option>
				<option value='(・ω・)'>(・ω・)</option>
				<option value='( ´・ω)'>( ´・ω)</option>
				<option value='(｀・ω)'>(｀・ω)</option>
				<option value='(´・ω・`)'>(´・ω・`)</option>
				<option value='(`・ω・´)'>(`・ω・´)</option>
				<option value='( `_っ´)'>( `_っ´)</option>
				<option value='( `ー´)'>( `ー´)</option>
				<option value='( ´_っ`)'>( ´_っ`)</option>
				<option value='( ´ρ`)'>( ´ρ`)</option>
				<option value='( ﾟωﾟ)'>( ﾟωﾟ)</option>
				<option value='(oﾟωﾟo)'>(oﾟωﾟo)</option>
				<option value='(　^ω^)'>(　^ω^)</option>
				<option value='(｡◕∀◕｡)'>(｡◕∀◕｡)</option>
				<option value='/( ◕‿‿◕ )\'>/( ◕‿‿◕ )\</option>
				<option value='ヾ(´ε`ヾ)'>ヾ(´ε`ヾ)</option>
				<option value='(ノﾟ∀ﾟ)ノ'>(ノﾟ∀ﾟ)ノ</option>
				<option value='(σﾟдﾟ)σ'>(σﾟдﾟ)σ</option>
				<option value='(σﾟ∀ﾟ)σ'>(σﾟ∀ﾟ)σ</option>
				<option value='|дﾟ )'>|дﾟ )</option>
				<option value='┃電柱┃'>┃電柱┃</option>
				<option value='ﾟ(つд`ﾟ)'>ﾟ(つд`ﾟ)</option>
				<option value='ﾟÅﾟ )　'>ﾟÅﾟ )　</option>
				<option value='⊂彡☆))д`)'>⊂彡☆))д`)</option>
				<option value='⊂彡☆))д´)'>⊂彡☆))д´)</option>
				<option value='⊂彡☆))∀`)'>⊂彡☆))∀`)</option>
				<option value='(´∀((☆ミつ'>(´∀((☆ミつ</option>
			</select>
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>内　文</b></td>
		<td>
			<textarea name="content" id="fcom" cols="48" rows="4" style="width: 320px; height: 80px;"></textarea>
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>外链图</b></td>
		<td>
			<input type="text" name="upfile" id="fupfile" style="width: 320px;" value="" />
		</td>
	</tr>
	<tr>
		<td class="Form_bg"><b>删文码</b></td>
		<td>
			<input type="password" name="pwd" id="fpwd" size="8" maxlength="8" value=""/>
			<small>(删除文章用,8位以内英文/数字密码)</small>
		</td>
	</tr>
</table>
<script type="text/javascript">newpost();</script>
<noscript>＊您选择关闭了JavaScript，但这对您的浏览及发文应无巨大影响。</noscript>
</form>
</div>
<!--end of template.newpost.php-->
