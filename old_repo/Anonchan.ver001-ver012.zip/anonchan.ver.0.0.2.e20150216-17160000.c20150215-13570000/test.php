<?php
require 'templet.head.php';
require 'templet.header.php';
require 'templet.newpost.php';
$id=12345;$image="http://www.baidu.com/img/baidu_jgylogo3.gif";$title="标题";$name="名字"; 
$createdAt=0;$tripcode="23456";$content="正文</br>正文";$replycount=10;$recentreplycount=6;

require 'templet.op.php';
$id=12345;$image="http://www.baidu.com/img/baidu_jgylogo3.gif";$title="标题";$name="名字"; 
$createdAt=0;$tripcode="23456";$content="正文</br>正文";$replycount=10;$recentreplycount=6;

require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.op.php';
$id=12345;$image="http://www.baidu.com/img/baidu_jgylogo3.gif";$title="标题";$name="名字"; 
$createdAt=0;$tripcode="23456";$content="正文</br>正文";$replycount=10;$recentreplycount=6;

require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.op.php';
$id=12345;$image="http://www.baidu.com/img/baidu_jgylogo3.gif";$title="标题";$name="名字"; 
$createdAt=0;$tripcode="23456";$content="正文</br>正文";$replycount=10;$recentreplycount=6;

require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.reply.php';
require 'templet.delpost.php';
$size=100; $page=97;

require 'templet.tail.php';
?>