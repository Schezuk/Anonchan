<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--template.head.php-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Cache-Control" content="max-age=0; must-revalidate" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Language" content="zh-cn" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes" />
    <title><?php echo $thread_title . $forum_title . ' - ' . $board_title;?></title>

    <link rel="stylesheet" type="text/css" href="mainstyle.css" />
    <script type="text/javascript" src="mainscript.js"></script>
    <!--[if lt IE 8]><script type="text/javascript" src="iedivfix.js"></script><![endif]-->
    <script type="text/javascript">
        // <![CDATA[
        var msgs=['在没有附加图片的情况下，请写入内容','附加图片为系统不支持的格式','侦测到您有输入樱花日文假名的可能性，将自动为您转换'];
        var ext="GIF|JPG|PNG|BMP".toUpperCase().split("|");
        // ]]>
        </script>
</head>
<!--end of template.head.php-->
