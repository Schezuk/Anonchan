<?php
//start up
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  
if (false === strpos($_SERVER['HTTP_REFERER'],'http'))
	$referer = $_SERVER['HTTP_REFERER'];
else	$referer = 'javascript:window.history.go(-1);';
//check params
$uid = getTripcode();
if (1 > ($id=intval($_REQUEST['id'])))		die(json_err('id',1,'invalid thread id'));
$blackhole = NULL;
$count  = safe_query("UPDATE `$TABLE_NAME` SET `hide` = (
	CASE WHEN `dislike` > ((`like`+1) * ? + ?) THEN 1 ELSE 0 END
	), `like` = `like` + 1, `liker` = 
	LEFT(CONCAT(?, ',' , `liker`), 512)
	WHERE `id` = ? AND 0 = INSTR(`like`, ?);", &$blackhole, array('iisis',
	$__hide_rate, $__hide_diff, $uid, $id, $uid));
//rating function: hide = 1 when newdislike > newlike * k + b
if (1 == $count) exitPage("like",0,$like_timeout,$like_goto,$like_succeeded);
else	exitPage("like",0,$like_timeout,$like_goto,$like_failed);
?>