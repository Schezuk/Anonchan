<?php
$tail_url = 'thread.php';
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  

// FIRST GET THREAD RATHER THAN REPLY
$thread = NULL;
$id=max(intval($_REQUEST['id']),1);//thread 0 is not accessable.
for ($i = 0; $i < 2; $i++) {
	if($i = 2) exitPage("thread", 0,$thread_timeout,$thread_goto,"data structure error, please report admin!");
	//if you havn't got root in 2 rounds, it must have erred.
	
	$result	= NULL;//`pwd`, `recentReply`'s are omitted. `delete` will always be 0.
	$count	= safe_query("SELECT 
	`id`, `parent`, `updatedAt`, `createdAt`, `replyCount`,
	`uid`, `name`, `email`, `title`, `image`, `content`,
	`hide`, `sage`, `lock`, `delete`
	`like`, `liker`, `dislike`, `disliker`,
	FROM `$TABLE_NAME` where `id` = ?;", 
	&$result, array('i',$id));
	if (1 == $count) $thread = $result[0];	else exitPage("thread",1,$thread_timeout,$thread_goto,$thread_not_exist);//reply or thread is gone.
	if (0 == $thread['parent']) break;	else $id = $thread['parent'];//when parent is 0,you got thread. If not, try again.
}
if (0 < $thread['delete']) exitPage("thread",2,$thread_timeout,$thread_goto,$thread_deleted);//if thread is gone, you won't see any replies.
// THREAD IS OBTAINED

// THEN GET REPLIES OF THE VERY THREAD
$replyCount = $thread['replyCount'];
$size	= ceil($replyCount/$replyPerPage);
$page	= max(min(intval($_REQUEST['page']),$size),1);;//page 0 is not accessable.

$result = NULL;//`pwd`, `recentReply`'s are omitted. `delete` will always be 0.
$count	= safe_query("SELECT 
	`id`, `parent`, `updatedAt`, `createdAt`, `replyCount`,
	`uid`, `name`, `email`, `title`, `image`, `content`,
	`hide`, `sage`, `lock`, `delete`
	`like`, `liker`, `dislike`, `disliker`,
	FROM `$TABLE_NAME` WHERE `parent` = ? AND `delete` = 0 
	ORDER BY `createdAt` DESC LIMIT ?, ?;",
	&$result , array('iii', $id, $replyPerPage * ($page - 1), $replyPerPage));
	//It is OK no matter how many (or none) replies you got in return.
foreach ($result as $reply) $replies[$reply['id']] = $reply;//push array. no need to unset $reply, and it will be reset in the next foreach.
// REPLIES ARE OBTAINED

// DATA ALL OBTAINED NOW
if(isset($_REQUEST['callback']))	exit ($_REQUEST['callback'] . '(' . unescape_utf8(json_encode(array('thread'=>$thread,'replies'=>$replies))) . ')');
else if(isset($_REQUEST['jsonp']))	exit ($_REQUEST['jsonp'] . '(' . unescape_utf8(json_encode(array('thread'=>$thread,'replies'=>$replies))) . ')');
else if(isset($_REQUEST['json']))	exit (unescape_utf8(json_encode(array('thread'=>$thread,'replies'=>$replies))));
// ELSE SHOW HTML

// REQUIRE TEMPLETS
$__thread_title = 'No.' . strval($id) . ' @ ';
require 'templet/head.php';
require 'templet/header.php';
require 'templet/newpost.php';

	$id = $thread['id'];
	$parent = $thread['parent'];
	$updatedAt = $thread['updatedAt'];
	$createdAt = $thread['createdAt'];
	$replyCount = $thread['replyCount'];

	$uid = $thread['uid'];
	$name = $thread['name'];
	$email = $thread['email'];
	$title = $thread['title'];
	$image = $thread['image'];
	$content = $thread['content'];

	$hide = $thread['hide'];
	$sage = $thread['sage'];
	$lock = $thread['lock'];
	$delete = $thread['delete'];

	$like = $thread['like'];
	$liker = $thread['liker'];
	$dislike = $thread['dislike'];
	$disliker = $thread['disliker'];
	$recentReplyCount = $replyCount;//therefore $omitted = 0;
require 'templet/op.php';

foreach ($replies as $reply){
	$id = $reply['id'];
	$parent = $reply['parent'];
	$updatedAt = $reply['updatedAt'];
	$createdAt = $reply['createdAt'];
	$replyCount = $reply['replyCount'];
	
	$uid = $reply['uid'];
	$name = $reply['name'];
	$email = $reply['email'];
	$title = $reply['title'];
	$image = $reply['image'];
	$content = $reply['content'];
	
	$hide = $reply['hide'];
	$sage = $reply['sage'];
	$lock = $reply['lock'];
	$delete = $reply['delete'];
	$like = $reply['like'];
	$liker = $reply['liker'];
	$dislike = $reply['dislike'];
	$disliker = $reply['disliker'];
require 'templet/reply.php';
}
require 'templet/delpost.php';
$size = $size;	//though there is no need.
$page = $page;	//though there is no need.
require 'templet/tail.php';
exit;
?>