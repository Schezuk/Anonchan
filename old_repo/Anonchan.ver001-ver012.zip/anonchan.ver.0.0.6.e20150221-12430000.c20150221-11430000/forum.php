<?php
$tail_url = 'forum.php';
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  

$result	= NULL;
$count	= safe_query("SELECT * 
	FROM `$TABLE_NAME` where `id` = 0;", 
	&$result, array('i',0));//access thread 0
if (1 != $count) exitPage("forum", 0,$forum_timeout,$forum_goto,"data structure error, please report admin!");

if (0 < $result[0]['delete']) exitPage("forum",2,$thread_timeout,$thread_goto,$forum_deleted);//if forum is gone, you won't see any threads.

$replyCount = $result[0]['replyCount'];
$size	= ceil($replyCount/$threadPerPage);
$page	= max(min(intval($_REQUEST['page']),$size),1);//page 0 is not accessable.

$result = NULL;//reused
$count	= safe_query("SELECT *
	FROM `$TABLE_NAME` WHERE `parent` = 0 AND `delete` = 0 
	ORDER BY `updatedAt` DESC LIMIT ?, ?;",//not createdAt!
	&$result, array('ii',  $threadPerPage * ($page - 1), $threadPerPage));
	//It is OK no matter how many (or none) replies there is.

//foreach will iterate in the order it is first pushed into array. exp: 
//$arr = array(4 => 'sss',3 => 'xxx', 5 => 'aaa');foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa
//$arr[3] = 'xxxx';foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa4sss3xxxx5aaa
$recentPerThread = min(max(floor($recentPerThread),0),20);//0 <= int recentPerThread <= 20
foreach ($result as $thread){// DON'T USE '&'! IT WILL BE COVERED!
	$id = $thread['id'];
	$reply_index_this = array();	//clear array.
	switch ($recentPerThread) {
	case 20: if ($thread['recentReply19'] > 0) {$reply_index_this[] = $thread['recentReply19'];}
	case 19: if ($thread['recentReply18'] > 0) {$reply_index_this[] = $thread['recentReply18'];}
	case 18: if ($thread['recentReply17'] > 0) {$reply_index_this[] = $thread['recentReply17'];}
	case 17: if ($thread['recentReply16'] > 0) {$reply_index_this[] = $thread['recentReply16'];}
	case 16: if ($thread['recentReply15'] > 0) {$reply_index_this[] = $thread['recentReply15'];}
	case 15: if ($thread['recentReply14'] > 0) {$reply_index_this[] = $thread['recentReply14'];}
	case 14: if ($thread['recentReply13'] > 0) {$reply_index_this[] = $thread['recentReply13'];}
	case 13: if ($thread['recentReply12'] > 0) {$reply_index_this[] = $thread['recentReply12'];}
	case 12: if ($thread['recentReply11'] > 0) {$reply_index_this[] = $thread['recentReply11'];}
	case 11: if ($thread['recentReply10'] > 0) {$reply_index_this[] = $thread['recentReply10'];}
	case 10: if ($thread['recentReply09'] > 0) {$reply_index_this[] = $thread['recentReply09'];}
	case  9: if ($thread['recentReply08'] > 0) {$reply_index_this[] = $thread['recentReply08'];}
	case  8: if ($thread['recentReply07'] > 0) {$reply_index_this[] = $thread['recentReply07'];}
	case  7: if ($thread['recentReply06'] > 0) {$reply_index_this[] = $thread['recentReply06'];}
	case  6: if ($thread['recentReply05'] > 0) {$reply_index_this[] = $thread['recentReply05'];}
	case  5: if ($thread['recentReply04'] > 0) {$reply_index_this[] = $thread['recentReply04'];}
	case  4: if ($thread['recentReply03'] > 0) {$reply_index_this[] = $thread['recentReply03'];}
	case  3: if ($thread['recentReply02'] > 0) {$reply_index_this[] = $thread['recentReply02'];}
	case  2: if ($thread['recentReply01'] > 0) {$reply_index_this[] = $thread['recentReply01'];}
	case  1: if ($thread['recentReply00'] > 0) {$reply_index_this[] = $thread['recentReply00'];}
	case  0;//do nothing
	}//recentReply00 will be pushed last. it is the newest reply of the thread.
	
	$tree_index[$id] = $reply_index_this;
	$reply_index     = $reply_index + $reply_index_this; // php.net tolds "+" is better than array_merge
	$thread_index[]  = $id;
	$threads[$id]	 = array('id' => $thread['id'],
				'parent' => $thread['parent'],
				'updatedAt' => $thread['updatedAt'],
				'createdAt' => $thread['createdAt'],
				'replyCount' => $thread['replyCount'],

				'uid' => $thread['uid'],
				'name' => $thread['name'],
				'email' => $thread['email'],
				'title' => $thread['title'],
				'image' => $thread['image'],
				'content' => $thread['content'],

				'hide' => $thread['hide'],
				'sage' => $thread['sage'],
				'lock' => $thread['lock'],
				'delete' => $thread['delete'],//it must be 0

				//pwd is omitted
				'like' => $thread['like'],
				'liker' => $thread['liker'],
				'dislike' => $thread['dislike'],
				'disliker' => $thread['disliker'],

				'recentReply' => $reply_index_this
				//array, in which there is no more than "recentPerThread" elements
				);
}

$reply_index_imploded = implode(',',$reply_index);//array of integers is fine.
$result = NULL;
$count	= safe_query("SELECT * 
	`id`, `parent`, `updatedAt`, `createdAt`, `replyCount`,
	`uid`, `name`, `email`, `title`, `image`, `content`,
	`hide`, `sage`, `lock`, `delete`
	`like`, `liker`, `dislike`, `disliker`,
	FROM `$TABLE_NAME` WHERE `id` IN [$reply_index_imploded] AND `delete` = ?;",
	//you may add ORDER BY `createdAt` or ORDER BY field(id,$reply_index_imploded), but it does hardly any good.
	&$result, array('i', 0)
	);//It is OK no matter how many (or none) replies there is.

foreach ($result as $reply) {// DON'T USE '&'! IT WILL BE COVERED!
	$reply_index = $reply['id'];//Refresh, the deleted items will not show now. However $threads[$id]['recentReply'] is not updated.
	$replies[$reply['id']] = $reply;
}
// There are $tree_index, $replies, $reply_index, $threads, $thread_index now.
// DATA ALL OBTAINED NOW
if(isset($_REQUEST['callback']))	exit ($_REQUEST['callback'] . '(' . unescape_utf8(json_encode(array('threads'=>$threads,'replies'=>$replies))) . ')');
else if(isset($_REQUEST['jsonp']))	exit ($_REQUEST['jsonp'] . '(' . unescape_utf8(json_encode(array('threads'=>$threads,'replies'=>$replies))) . ')');
else if(isset($_REQUEST['json']))	exit (unescape_utf8(json_encode(array('threads'=>$threads,'replies'=>$replies))));
// ELSE SHOW HTML
// REQUIRE TEMPLETS
$__thread_title = 'No.' . strval($id) . ' @ ';
require 'templet/head.php';
require 'templet/header.php';
require 'templet/newpost.php';

foreach ($threads as $thread_id =>$thread){//$thread is refreshed
	$id = $thread['id'];
	$parent = $thread['parent'];
	$updatedAt = $thread['updatedAt'];
	$createdAt = $thread['createdAt'];
	$replyCount = $thread['replyCount'];

	$uid = $thread['uid'];
	$name = $thread['name'];
	$email = $thread['email'];
	$title = $thread['title'];
	$image = $thread['image'];
	$content = $thread['content'];

	$hide = $thread['hide'];
	$sage = $thread['sage'];
	$lock = $thread['lock'];
	$delete = $thread['delete'];

	$like = $thread['like'];
	$liker = $thread['liker'];
	$dislike = $thread['dislike'];
	$disliker = $thread['disliker'];

	$recentReplyCount = count($thread['recentReply']);

	require 'templet/op.php';

	foreach ($thread['recentReply'] as $reply_id){
		$id = $replies[$reply_id]['id'];
		$parent = $replies[$reply_id]['parent'];
		$updatedAt = $replies[$reply_id]['updatedAt'];
		$createdAt = $replies[$reply_id]['createdAt'];
		$replyCount = $replies[$reply_id]['replyCount'];
	
		$uid = $replies[$reply_id]['uid'];
		$name = $replies[$reply_id]['name'];
		$email = $replies[$reply_id]['email'];
		$title = $replies[$reply_id]['title'];
		$image = $replies[$reply_id]['image'];
		$content = $replies[$reply_id]['content'];
	
		$hide = $replies[$reply_id]['hide'];
		$sage = $replies[$reply_id]['sage'];
		$lock = $replies[$reply_id]['lock'];
		$delete = $replies[$reply_id]['delete'];
	
		$like = $replies[$reply_id]['like'];
		$liker = $replies[$reply_id]['liker'];
		$dislike = $replies[$reply_id]['dislike'];
		$disliker = $replies[$reply_id]['disliker'];

		require 'templet/reply.php';
	}
}
require 'templet/delpost.php';
$size = $size;	
$page = $page;
require 'templet/tail.php';
exit;
?>