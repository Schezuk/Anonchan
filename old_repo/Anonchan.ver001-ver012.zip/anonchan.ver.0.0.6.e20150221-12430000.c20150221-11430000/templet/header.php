<!--template.header.php-->
<body>
<div id="header">
    <div id="toplink">
        [<a href="forum.php?page=1" rel="_top"><?php echo $__return_home; ?></a>]
        [<a href="?"><?php echo $__refresh; ?></a>]
    </div>
    <br />
    <h1><?php echo $__thread_title . $__forum_title;?></h1>
    <hr class="top" />
</div>
<!--end of template.header.php-->
