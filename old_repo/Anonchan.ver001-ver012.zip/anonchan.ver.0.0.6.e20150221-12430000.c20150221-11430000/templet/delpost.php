<!--template.delpost.php-->
<hr />
<div id="del">
	<form action="delete.php" method="post" enctype="multipart/form-data" onsubmit="return check_reply();" id="postform_main">
		<table style="float: right;">
			<tr>
				<td align="center" style="white-space: nowrap;"><?php echo $__delete_post; ?></td>
				<td><?php echo $__post_reply_id; ?></td>
				<td>
					<input type="text" name="id" id="fid" size="10" maxlength="10" value=""/>
				</td>
				<td><?php echo $__pwd_to_delete; ?></td>
				<td>
					<input type="password" name="pwd" id="fpwd" size="8" maxlength="8" value=""/>
				</td>
				<td>
					[<input type="checkbox" name="onlyimgdel" id="onlyimgdel" value="on" /><label for="onlyimgdel"><?php echo $__onlyimgdel; ?></label>]
				</td>
				<td>
					<input type="submit" value="<?php echo $__del_execute; ?>" />
				</td>
	        	</tr>
		</table>
	</form>
</div>
<script type="text/javascript">delpost();</script>
<!--end of template.delpost.php-->
