<!--template.tail.php-->
<div id="page_switch">
	<div>
		[<a class="prev" href="<?php echo $tail_url; ?>?page=1"><?php echo $__first_page; ?></a>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page-4; if(0<$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-3; if(0<$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-2; if(0<$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page-1; if(0<$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		}?>
		[<span class="current"><?php echo $page; ?></span>]
		<?php if(0 < $page && $page<=$size){
		$page_switch=$page+1; if($size>=$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+2; if($size>=$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+3; if($size>=$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		$page_switch=$page+4; if($size>=$page_switch) echo "[<a class=\"num\" href=\"$tail_url?page=$page_switch\">$page_switch</a>]";
		}?>
		[<a class="end" href="<?php echo $tail_url; ?>?page=<?php echo $size; ?>"><?php echo $__last_page; ?></a>]
	</div>
</div>
<div id="footer">
	<script type="text/javascript">preset();</script>
	<!--Space for Web Analytics Service.-->
	<?php echo $__statUrl; ?>
	<!--End of space for Web Analytics Service.-->
</div>
</body>
</html>
<!--end of template.tail.php-->
