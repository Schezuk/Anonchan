<!--template.reply.php-->
<div class="reply" id="<?php echo $id; ?>"><div class="replywrap">
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='<?php echo $id; ?>'; else $_('fid').value='';" />
	<?php if ($image!=='') echo "<img src='$image' class='img' style='max-width:250px; max-height:250px' />"; ?>
	<span class="title"><?php if ($title=='') echo $__no_title; else echo $title; ?></span>
	<span class="name" ><?php if ($name =='') echo $__no_name;  else echo $name;  ?></span>
	<span class="email" ><?php echo $email;  ?></span>
	<span class="time" ><?php echo date('Y-m-d H:i:s', $createdAt); ?></span>
	<span class="uid">[ID:<?php echo $uid; ?>]</span>
	<a href="<?php
		 if ('thread.php'==$tail_url) echo 'javascript:quote(', $id, ')'; 
		 if ('forum.php' ==$tail_url) echo 'thread.php?id=', $parent, '#', $id;
		 ?>" class="qlink">No.<?php echo $id; ?></a>
	<br />
	<?php if ($hide>0) echo "<DIV style='cursor:hand' onclick='isHidden(\"h$id\")'>$__isHidden</DIV>"; ?>
	<div class="quote" <?php if ($hide>0) echo 'id="h$id" style="display:none;"'?>><?php echo $content; ?></div>
	<div class="like"><?php echo str_replace('####', $like, $__like); ?></div>
	<div class="liker"><?php if ($__show_liker > 0) echo $__show_them,$liker; ?></div>
	<div class="dislike"><?php echo str_replace('####', $dislike, $__dislike); ?></div>
	<div class="disliker"><?php if ($__show_disliker > 0) echo $__show_them,$disliker; ?></div>
</div></div>
<!--end of template.reply.php-->
