<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--template.head.php-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Cache-Control" content="max-age=0; must-revalidate" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Language" content="zh-cn" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes" />
    <meta name="save" content="history">  
    <title><?php echo $__thread_title . $__forum_title . ' - ' . $__board_title;?></title>

    <link rel="stylesheet" type="text/css" href="src/mainstyle.css" />
    <script type="text/javascript" src="src/mainscript.js"></script>
    <!--[if lt IE 8]><script type="text/javascript" src="src/iedivfix.js"></script><![endif]-->
    <script type="text/javascript">
        // <![CDATA[
        var msgs=['<?php echo $__messages[0]; ?>','<?php echo $__messages[1]; ?>','<?php echo $__messages[2]; ?>'];
        var ext="GIF|JPG|PNG|BMP".toUpperCase().split("|");
        // ]]>
    </script>
    <SCRIPT>function isHidden(oDiv){var vDiv = document.getElementById(oDiv);vDiv.style.display = (vDiv.style.display == 'none')?'block':'none';}</SCRIPT>
</head>
<!--end of template.head.php-->
