<!--template.op.php-->
<hr/>
<div class="threadpost" id="<?php echo $id; ?>"> 
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='<?php echo $id; ?>'; else $_('fid').value='';" />
	<?php if ($image!=='') echo '<img src="', $image,'" class="img" style="max-width:250px; max-height:250px" />'; ?>
	<span class="title"><?php if ($title=='') echo $__no_title; else echo $title; ?></span>
	<span class="name" ><?php if ($name =='') echo $__no_name; else echo $name;  ?></span>
	<span class="email" ><?php echo $email;  ?></span>
	<span class="sage" style="color: #FF0000"><?php if (0 < $sage) echo 'SAGE'; ?></span>
	<span class="time" ><?php echo date('Y-m-d H:i:s', $createdAt); ?></span>
	<span class="uid">[ID:<?php echo $uid; ?>]</span>
	<a href="thread.php?id=<?php echo $id; ?>" class="qlink">No.<?php echo $id; ?></a>
	&nbsp;
	<a href="thread.php?id=<?php echo $id; ?>"><?php echo $__reply; ?></a>
	<br />
	<?php if ($hide>0) echo "<DIV style='cursor:hand' onclick='isHidden(\"h$id\")'>$__isHidden</DIV>"; ?>
	<div class="quote" <?php if ($hide > 0) echo 'id="h$id" style="display:none;"'?>><?php echo $content; ?></div>
	<div class="like"><?php echo str_replace('####', $like, $__like); ?></div>
	<div class="liker"><?php if ($__show_liker > 0) echo $__show_them,$liker; ?></div>
	<div class="dislike"><?php echo str_replace('####', $dislike, $__dislike); ?></div>
	<div class="disliker"><?php if ($__show_disliker > 0) echo $__show_them,$disliker; ?></div>
	<?php $omitted = $replyCount - $recentReplyCount;
	if ($omitted > 0) echo '<br/><span class="warn_txt2">' . str_replace('####',strval($omitted),$__omission) . '</span>'; ?>
</div>
<!--end of template.op.php-->
