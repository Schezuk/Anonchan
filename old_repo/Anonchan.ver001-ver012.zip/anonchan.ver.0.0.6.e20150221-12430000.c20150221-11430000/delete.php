<?php
//start up
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  
if (false === strpos($_SERVER['HTTP_REFERER'],'http'))
	$referer = $_SERVER['HTTP_REFERER'];
else	$referer = 'javascript:window.history.go(-1);';
//check params
if (1 > ($id=intval($_REQUEST['id'])))		die(json_err('id',1,'invalid thread id'));
if (''==($pwd=substr($_REQUEST['pwd'],0,8)))	die(json_err('pwd',1,'invalid password'));
if ('on'===($onlyimgdel=intval($_REQUEST['onlyimgdel']))){
	$blackhole = NULL;
	$count  = safe_query("UPDATE `$TABLE_NAME` SET `image` = '' WHERE `id` = ? AND `pwd` = ?;", &$blackhole, array('is',$id,$pwd));
	if (1 == $count)exitPage("delete", 0,$delete_timeout,$delete_goto,$delete_succeeded);
	else		exitPage("delete",-1,$delete_timeout,$delete_goto,$delete_failed);
} else {
	$blackhole = NULL;
	$count  = safe_query("UPDATE `$TABLE_NAME` SET `delete` = 1 WHERE `id` = ? AND `pwd` = ?;", &$blackhole, array('is',$id,$pwd));
	if (1 == $count)exitPage("delete", 0,$delete_timeout,$delete_goto,$delete_succeeded);
	else		exitPage("delete",-1,$delete_timeout,$delete_goto,$delete_failed);
}
?>
