<?php
require ('lib/mysqli.php');
header("Access-Control-Allow-Origin: *"); 
header("Cache-Control: no-store, no-cache, must-revalidate");  
header("Cache-Control: post-check=0, pre-check=0", false);  
header("Pragma: no-cache");  

//get params from the form.
$parent	= max(intval($_POST['id']),0);
$time	= time();
$uid	= getTripcode();
$name	= htmlspecialchars($_POST['name'], ENT_NOQUOTES, 'UTF-8');
$email	= htmlspecialchars($_POST['email'], ENT_NOQUOTES, 'UTF-8');
$title	= htmlspecialchars($_POST['title'], ENT_NOQUOTES, 'UTF-8');
$image	= htmlspecialchars($_POST['image'], ENT_NOQUOTES, 'UTF-8');
$content= htmlspecialchars($_POST['content'], ENT_NOQUOTES, 'UTF-8');
$pwd	= $_POST['pwd'];


if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$image)) {
	exitPage("post",-2,$post_timeout,$post_goto,$post_image_not_valid);
} 
//else $image_header = get_headers($image,1);
//NO, even SINA's image (ww#.sinaimg.cn) has no "Content-Type:" in Response Headers.
//anyway it seems "img src" have no XSS leaks after url validation	
//see https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet

//anti-spam
$result	= NULL;
$count	= safe_query("SELECT `content` FROM `$TABLE_NAME` where id=?;", &$result, array('i',0));
if (1 !== $count) exitPage("post",-1,$post_timeout,$post_goto,"data structure error, please report admin!");
$raw_record = $result[0][`content`];
$record	= explode(';',$raw_record);
foreach ($record as $recorder) {
	$recorder = explode(',',$recorder);
	if ($recorder[0] === $uid and $recorder[1] > $time - $coolDown) exitPage("post",-1,$post_timeout,$post_goto,$post_coolDown);
}

//check parent status
$result	= NULL;
$count	= safe_query("SELECT * FROM `$TABLE_NAME` where id=?;", &$result, array('i',$parent));
if (1 !== $count) exitPage("post",-1,$post_timeout,$post_goto,$post_parent_not_exist);

if (1 != $count) 
	exitPage("post",1,$post_timeout,$post_goto,$post_parent_not_exist);
if (0 !=$result[0]['delete'])
	exitPage("post",2,$post_timeout,$post_goto,$post_parent_deleted);
if (0 !=$result[0]['lock'])
	exitPage("post",3,$post_timeout,$post_goto,$post_parent_locked);

//get params from the parent.
if (0 !=$result[0]['parent']) $parent = $result[0]['parent'];
$parent_replyCount=$result[0]['replyCount'];
if (stripos($email,'sage') !== false and stripos($email,'@' ===false )) $sage = 1;else $sage = 0;
if ($result[0]['sage']>0 or $sage >0 ) $time = $result[0]['updatedAt'];//When parent saged or myself saged, parent.updatedAt will not change.
//create new thread.
$blackhole = NULL;
$count = safe_query('INSERT INTO `sougou` (
  `parent`, `updatedAt`, `createdAt`, `replyCount`, 
  `uid`, `name`, `email`, `title`, `image`, `content`, 
  `hide`, `sage`, `lock`, `deleted`, `pwd`, `like`, `liker`, `dislike`, `disliker`, 
  `recentReply00`, `recentReply01`, `recentReply02`, `recentReply03`, `recentReply04`, 
  `recentReply05`, `recentReply06`, `recentReply07`, `recentReply08`, `recentReply09`, 
  `recentReply10`, `recentReply11`, `recentReply12`, `recentReply13`, `recentReply14`, 
  `recentReply15`, `recentReply16`, `recentReply17`, `recentReply18`, `recentReply19`
) VALUES (
  ?, ?, ?, 0,
  ?, ?, ?, ?, ?, ?, 
  0, ?, 0, 0, ?, 0, "", 0, "", 
  0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0 
);', &$blackhole, array('iiissssssis',
$parent, $time, $time,
$uid, $name, $email, $title, $image, $content,
$sage, $pwd
)
);
//update parent thread.
$blackhole = NULL;
$last_insert_id = $GLOBALS["safe_query_insert_id"];
if (1 != $count) 
	exitPage("post",4,$post_timeout,$post_goto,$post_newpost_failed);
$count = safe_query("UPDATE `$TABLE_NAME` SET 
`updatedAt`  = ?, `replyCount` = `replyCount` + 1,
`recentReply00` = ?, `recentReply01` = ?, `recentReply02` = ?, `recentReply03` = ?, `recentReply04` = ?, 
`recentReply05` = ?, `recentReply06` = ?, `recentReply07` = ?, `recentReply08` = ?, `recentReply09` = ?, 
`recentReply10` = ?, `recentReply11` = ?, `recentReply12` = ?, `recentReply13` = ?, `recentReply14` = ?, 
`recentReply15` = ?, `recentReply16` = ?, `recentReply17` = ?, `recentReply18` = ?, `recentReply19` = ?
WHERE `id` = ?;", &$blackhole, array('iiiiiiiiiiiiiiiiiiiii', 
             $time, $parent, $result[0]['recentReply00'], $result[0]['recentReply01'], $result[0]['recentReply02'], $result[0]['recentReply03'], 
$result[0]['recentReply04'], $result[0]['recentReply05'], $result[0]['recentReply06'], $result[0]['recentReply07'], $result[0]['recentReply08'], 
$result[0]['recentReply09'], $result[0]['recentReply10'], $result[0]['recentReply11'], $result[0]['recentReply12'], $result[0]['recentReply13'], 
$result[0]['recentReply14'], $result[0]['recentReply15'], $result[0]['recentReply16'], $result[0]['recentReply17'], $result[0]['recentReply18']
));
if (1 !== $count) exitPage("post",5,$post_timeout,$post_goto,$post_update_failed);
else{
//anti-spam
	if ('' === $raw_record) $raw_record = $uid . ',' . $str_pad($time, 11, "0", STR_PAD_LEFT);
	else if (strlen($raw_record) > 2027) // ( 8 + 1 + 11 + 1) + strlen  > 2048
		$raw_record = $uid . ',' . $str_pad($time, 11, "0", STR_PAD_LEFT) . ";" . substr($raw_record, 0, -21);
		//cut last ';AAAAAAAA,1400000000'
	else $raw_record = $uid . ',' . $str_pad($time, 11, "0", STR_PAD_LEFT) . ";" . $raw_record;//timestamp must be left-padded.
}
$blackhole = NULL;
$count = safe_query("UPDATE `$TABLE_NAME` SET `content` = ? WHERE `id` = 0;", &$blackhole, array('s',$raw_record));
if (1 !== $count) exitPage("post",-1,$post_timeout,$post_goto,"data structure error, please report admin!");
else exitPage("post",0,$post_timeout,$post_goto,$post_succeeded);//success!

?>