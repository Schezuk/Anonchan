<?php
require_once './initialize.php';
try {
	$info = new Forum($_REQUEST['page']);
	$info->fetch();
	Config::showInfo($info);
} catch (Exception $e) {
	Config::showError($e);
}
exit;
