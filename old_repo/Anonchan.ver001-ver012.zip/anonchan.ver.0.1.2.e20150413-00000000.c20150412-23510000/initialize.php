<?php
# Beware that EVERY accessible api should be stored in ROOT folder!
require_once './cls/config.cls.php';
require_once './cls/language.cls.php';
require_once './cls/mypdo.cls.php';
require_once './cls/node.cls.php';

