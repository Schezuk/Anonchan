<?php
Interface TableSize {
	const MAX_INTEGER     = 2147483647;
	const LEN_ID          =          4;
	const LEN_PARENT      =          4;
	const LEN_UPDATEDAT   =          4;
	const LEN_CREATEDAT   =          4;
	const LEN_REPLYCOUNT  =          4;
	const LEN_UID         =          8;
	const LEN_NAME        =        255;
	const LEN_EMAIL       =        255;
	const LEN_TITLE       =        255;
	const LEN_IMAGE       =        255;
	const LEN_CONTENT     =       2048;
	const LEN_PWD         =          8;
	const LEN_LIKE        =          4;
	const LEN_LIKER       =        252; # Comma Separated
	const LEN_DISLIKE     =          4;
	const LEN_DISLIKER    =        252; # Comma Separated
	const LEN_RECENTREPLY =          4;
	const LEN_REPLYRECORD =       2000;
}
Interface SqlQuery {
	const QUERY_PARAM = array(
				# POST
				'POST_INSERT'  => array('parent','updatedAt','createdAt','uid','name','email','title','image','content','sage','pwd'),
				'DADY_UPDATE'  => array('updatedAt','parent'),
				'ROOT_UPDATE'  => array('createdAt','uid'),
				# READ
				'NODE_SELECT'  => array('id'),
				'SONS_SELECT'  => array(),
				'PAGE_SELECT'  => array('parent','page','offset'),
				# EDIT
				'POST_DELIMG'  => array('id','pwd'),
				'POST_DELETE'  => array('id','pwd'),
				'POST_LIKE'    => array('id','uid'),
				'POST_DISLIKE' => array('id','uid'),
				# ADMIN FUNCTIONS
				'ADMIN_DEL'    => array('id'),
				'ADMIN_SAGE'   => array('id'),
				'ADMIN_LOCK'   => array('id'),
				'ADMIN_HIDE'   => array('id'),
				'ADMIN_UNDEL'  => array('id'),
				'ADMIN_UNSAGE' => array('id'),
				'ADMIN_UNLOCK' => array('id'),
				'ADMIN_UNHIDE' => array('id'),
				'ADMIN_EDIT'   => array('id','content'),
				'ADMIN_RENAME' => array('id')
	);
	CONST QUERY_CONST = array(
				# POST
				'POST_INSERT'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'DADY_UPDATE'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME, '{$LEN_REPLYRECORD}' => TableSize::LEN_REPLYRECORD),
				'ROOT_UPDATE'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				# READ
				'NODE_SELECT'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'SONS_SELECT'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'PAGE_SELECT'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				# EDIT
				'POST_DELIMG'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'POST_DELETE'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'POST_LIKE'    => array('{$TABLENAME}'=>CONFIG::TABLE_NAME, '{$LEN_REPLYRECORD}' => TableSize::LEN_REPLYRECORD),
				'POST_DISLIKE' => array('{$TABLENAME}'=>CONFIG::TABLE_NAME, '{$LEN_REPLYRECORD}' => TableSize::LEN_REPLYRECORD),
				# ADMIN FUNCTIONS
				'ADMIN_DEL'    => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_SAGE'   => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_LOCK'   => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_HIDE'   => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_UNDEL'  => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_UNSAGE' => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_UNLOCK' => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_UNHIDE' => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_EDIT'   => array('{$TABLENAME}'=>CONFIG::TABLE_NAME),
				'ADMIN_RENAME' => array('{$TABLENAME}'=>CONFIG::TABLE_NAME)
	);
}
#