<?php
interface SqlStmt {
	# DATABASE
	const OPTIONS = array(
			PDO::ATTR_CASE                    => PDO::CASE_NATURAL,
			PDO::ATTR_TIMEOUT                 => 10,
			PDO::ATTR_ERRMODE                 => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_ORACLE_NULLS            => PDO::NULL_TO_STRING,
			PDO::ATTR_DEFAULT_FETCH_MODE      => PDO::FETCH_ASSOC,
			PDO::MYSQL_ATTR_FOUND_ROWS        => TRUE,
			PDO::MYSQL_ATTR_INIT_COMMAND      => 'SET NAMES \'UTF8\'',
			PDO::MYSQL_ATTR_USE_BUFFERED_QUERY=> false
	);
	const QUERY_STATEMENT = array(
				# POST
				'NODE_INSERT'  => 'INSERT INTO `{$TABLENAME}` (
									`parent`, `updatedAt`, `createdAt`, `replyCount`,`uid`, `name`, `email`, `title`, `image`, `content`,
									`hide`, `sage`, `lock`, `deleted`, `pwd`, `like`, `liker`, `dislike`, `disliker`,
									`recentReply00`, `recentReply01`, `recentReply02`, `recentReply03`, `recentReply04`,
									`recentReply05`, `recentReply06`, `recentReply07`, `recentReply08`, `recentReply09`,
									`recentReply10`, `recentReply11`, `recentReply12`, `recentReply13`, `recentReply14`,
									`recentReply15`, `recentReply16`, `recentReply17`, `recentReply18`, `recentReply19`
									) VALUES (
									:parent, :updatedAt, :createdAt, 0, :uid, :name, :email, :title, :image, :content,
									0, :sage, 0, 0, :pwd, 0, "", 0, "",
									0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
									);',
				'DADY_UPDATE'  => 'UPDATE `{$TABLENAME}` SET
								    `updatedAt`  = :updatedAt,
									`replyCount` = `replyCount` + 1,
								    `recentReply19` = `recentReply18`,
								    `recentReply18` = `recentReply17`,
								    `recentReply17` = `recentReply16`,
								    `recentReply16` = `recentReply15`,
								    `recentReply15` = `recentReply14`,
								    `recentReply14` = `recentReply13`,
								    `recentReply13` = `recentReply12`,
								    `recentReply12` = `recentReply11`,
								    `recentReply11` = `recentReply10`,
								    `recentReply10` = `recentReply09`,
								    `recentReply09` = `recentReply08`,
								    `recentReply08` = `recentReply07`,
								    `recentReply07` = `recentReply06`,
								    `recentReply06` = `recentReply05`,
								    `recentReply05` = `recentReply04`,
								    `recentReply04` = `recentReply03`,
								    `recentReply03` = `recentReply02`,
								    `recentReply02` = `recentReply01`,
								    `recentReply01` = `recentReply00`,
								    `recentReply00` = :recentReply00
									WHERE `id` = :parent;',
				'ROOT_UPDATE'  => 'UPDATE `{$TABLENAME}` SET `content` = SUBSTR((CHAR(:createdAt)||:uid||`content`),1,{$LEN_REPLYRECORD}) WHERE `id` = 0;',
				# READ
				'NODE_SELECT'  => 'SELECT * FROM `{$TABLENAME}` WHERE `id` = :id;',
				'SONS_SELECT'  => 'SELECT * FROM `{$TABLENAME}` WHERE `id` IN ({$NODES});',
				'PAGE_SELECT'  => 'SELECT * FROM `{$TABLENAME}` WHERE `parent` = :parent ORDER BY `updatedAt` DESC LIMIT :offset*(:page-1) OFFSET :offset;',
				# EDIT
				'POST_DELIMG'  => 'UPDATE `{$TABLENAME}` SET `image` = "" WHERE `id` = :id AND `pwd` = :pwd;',
				'POST_DELETE'  => 'UPDATE `{$TABLENAME}` SET `delete` = 1 WHERE `id` = :id AND `pwd` = :pwd;',
				'POST_LIKE'    => 'UPDATE `{$TABLENAME}` SET
									`hide` = (CASE WHEN `dislike` > ((`like` + 1) * $HIDE_RATIO + $HIDE_DIVIATION) THEN 1 ELSE 0 END),
								    `like` = `like` + 1,
									`liker` = SUBSTR((:uid||","||`liker`) ,1 , {$LEN_LIKER})
									WHERE `id` = :id AND `liker` NOT LIKE CONCAT("%", :uid, ",", "%");',
				'POST_DISLIKE' => 'UPDATE `{$TABLENAME}` SET
									`hide` = (CASE WHEN (`dislike` + 1) > (`like` * $HIDE_RATIO + $HIDE_DIVIATION) THEN 1 ELSE 0 END),
									`dislike`  = `dislike` + 1,
									`disliker` = SUBSTR((:uid||","||`disliker`), 1, {$LEN_DISLIKER})
									WHERE `id` = :id AND `disliker` NOT LIKE CONCAT("%", :uid, ",", "%");',
				# ADMIN FUNCTIONS
				'ADMIN_DEL'    => 'UPDATE `{$TABLENAME}` SET `delete` = `delete` + 1 WHERE `id` = :id;',
				'ADMIN_SAGE'   => 'UPDATE `{$TABLENAME}` SET `sage`   = `sage`   + 1 WHERE `id` = :id;',
				'ADMIN_LOCK'   => 'UPDATE `{$TABLENAME}` SET `lock`   = `lock`   + 1 WHERE `id` = :id;',
				'ADMIN_HIDE'   => 'UPDATE `{$TABLENAME}` SET `hide`   = `hide`   + 1 WHERE `id` = :id;',
				'ADMIN_UNDEL'  => 'UPDATE `{$TABLENAME}` SET `delete` = (CASE WHEN `delete` > 0 THEN `delete` - 1 ELSE 0 END) WHERE `id` = :id;',
				'ADMIN_UNSAGE' => 'UPDATE `{$TABLENAME}` SET `sage`   = (CASE WHEN `sage`   > 0 THEN `sage`   - 1 ELSE 0 END) WHERE `id` = :id;',
				'ADMIN_UNLOCK' => 'UPDATE `{$TABLENAME}` SET `lock`   = (CASE WHEN `lock`   > 0 THEN `lock`   - 1 ELSE 0 END) WHERE `id` = :id;',
				'ADMIN_UNHIDE' => 'UPDATE `{$TABLENAME}` SET `hide`   = (CASE WHEN `hide`   > 0 THEN `hide`   - 1 ELSE 0 END) WHERE `id` = :id;',
				'ADMIN_EDIT'   => 'UPDATE `{$TABLENAME}` SET `content`= "name: "||`name`||"<br />content: "||`content`||"<br />edit time:"||NOW()||"<br /><hr />"||:content WHERE `id` = :id;',
				'ADMIN_RENAME' => 'UPDATE `{$TABLENAME}` SET `name` = "<b><div style=\"color=#FF0000\">ADMIN</div>" WHERE `id` = :id;'
	);
}
