<?php
require_once './pdo/param.inc.php';
switch (strtolower(CONFIG::DB_TYPE)){
	case 'cubrid':  require_once './pdo/cubrid.inc.php';  break;
	case 'sybase':  require_once './pdo/sybase.inc.php';  break;
	case 'mssql':   require_once './pdo/mssql.inc.php';   break;
	case 'dblib':   require_once './pdo/dblib.inc.php';   break;
	case 'firebird':require_once './pdo/firebird.inc.php';break;
	case 'ibm':     require_once './pdo/ibm.inc.php';     break;
	case 'informix':require_once './pdo/informix.inc.php';break;
	case 'mysql':   require_once './pdo/mysql.inc.php';   break;
	case 'sqlsrv':  require_once './pdo/sqlsrv.inc.php';  break;
	case 'oci':     require_once './pdo/oci.inc.php';     break;
	case 'odbc':    require_once './pdo/odbc.inc.php';    break;
	case 'pgsql':   require_once './pdo/pgsql.inc.php';   break;
	case 'sqlite':  require_once './pdo/sqlite.inc.php';  break;
	case '4D':      require_once './pdo/4D.inc.php';      break;
	default:        require_once './pdo/mysql.inc.php';   break;
	}

class MyPdo implements TableSize, SqlQuery, SqlStmt {
	# PDO
	public $queryParam, $transactionCounter;
	protected $pdo, $queryStmt, $queryConst;
	public function __construct(){
		$this->queryParam = self::QUERY_PARAM;
		$this->transactionCounter = 0;
		$this->pdo =new PDO(CONFIG::DB_TYPE.':dbname='.CONFIG::DB_NAME.';host='.CONFIG::DB_HOST.';port='.CONFIG::DB_PORT.';charset=UTF8',
							CONFIG::DB_USER, 
							CONFIG::DB_PSWD, 
							SqlStmt::OPTIONS
							);
		$this->queryStmt  = self::QUERY_STATEMENT;
		$this->queryConst = self::QUERY_CONST;
		foreach ($this->queryStmt as $key => &$value)
			foreach ($this->queryConst[$key] as $search => $replace)
				str_replace($search, $replace, $value);
				
	}
	public function beginTransaction()	{
		if(!$this->transactionCounter++) return $this->pdo->beginTransaction();
		else return $this->transactionCounter >= 0;
	}	
	public function commit() {
		if(!--$this->transactionCounter) return $this->pdo->commit();
		else return $this->transactionCounter >= 0;
	}
	public function rollback() {
		if($this->transactionCounter >= 0) {$this->transactionCounter = 0; return $this->pdo->rollback();}
		else {$this->transactionCounter = 0; return false;}
	}
	public function exec($stmtKey, $stmtParam, $stmtClass = NULL){
		$sql =  $this->queryStmt[$stmtKey];
		if (isset($stmtParam['{$NODES}'])) {
			$sql = str_replace('{$NODES}', implode(', ', $stmtParam['{$NODES}']), $sql);
			unset($stmtParam['{$NODES}']); 
		}
		$stmt = $this->pdo->prepare($sql);
		foreach ($stmtParam as $key => $value) $stmt->bindValue(':' . $key, $value);
		$status = $stmt->execute();
		if     ($status  ===  false) return array('status' => $status, 'count' => 0, 'result' => array()); 
		elseif (is_null($stmtClass)) return array('status' => $status, 'count' => $stmt->rowCount(), 'result' => array());
		else {
			$count = 0;
			$result = array();
			$stmt->setFetchMode(PDO::FETCH_CLASS, $stmtClass);
			while (is_object($obj = $stmt->fetch(PDO::FETCH_CLASS))){
				$count++;
				$result[$obj->id] = $obj;
			}
			return array('status' => $status, 'count' => $count, 'result' => $result);
		}
	}
}
$GLOBALS['pdo'] = new MyPdo();
