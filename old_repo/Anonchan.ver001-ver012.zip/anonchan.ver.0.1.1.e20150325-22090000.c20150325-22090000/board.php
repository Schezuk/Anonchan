<?php
try {
# INIT
    require './init.php';
    $pdo = new PDO($dsn, $username, $password, $options);
    $INFO               = array();
    $THREAD             = array();
    $REPLY              = array();
    $THREADS            = array();
    $REPLIES            = array();
# INFO
    # `hide`, `sage` of root is always true. INC `lock`/`delete` of root and threads will lock/lock & delete the whole forum.
    $sth = $pdo->query("SELECT `lock`, `delete`, `replyCount` FROM `{$TABLE_NAME}` where `id` = 0;"); # Double Quote
    if (false === $sth)                 throw new Exception(FAILURE::ROOT_SELECT, -1);
    if (false ===($ret = $sth->fetch()))throw new Exception(FAILURE::ROOT_FETCH, -1);
    if (false === $sth->closeCursor())  throw new Exception(FAILURE::ROOT_CLOSECURSOR, -1);
    unset($sth);
    if ($ret['delete'] > 0)             throw new Exception(FAILURE::ROOT_DELETED, -1);
    $INFO['type']       = 'forum';
    $INFO['url']        = './forum.php?';
    $INFO['title']      = "{$FORUM_NAME} - {$BOARD_NAME}";
echo    $INFO['lock']       = $ret['lock'];
echo    $INFO['delete']     = $ret['delete'];
echo    $INFO['replyCount'] = $ret['replyCount'];
    $INFO['size']       = ceil($INFO['replyCount'] / $THREADS_PER_PAGE);
    $INFO['page']       = intrange($_REQUEST['page'], 1, $INFO['size']); //page 0 is not accessable.
    unset($ret); #INFO will survive.
# THREADS
    $replyIndex = array();
    $sth = $pdo->prepare("SELECT * FROM `{$TABLE_NAME}` WHERE `parent` = 0 ORDER BY `updatedAt` DESC LIMIT :limit OFFSET :offset;");
    if (false === $sth->execute(array(':limit'   => $THREADS_PER_PAGE * ($INFO['page'] - 1), ':offset'  => $THREADS_PER_PAGE)))
        throw new Exception(FAILURE::THREAD_SELECT, -1); # $sth->rowCount() will not work. #  No `delete` = 0, no empty page.
    while ($thread = $sth->fetch(PDO::FETCH_ASSOC)) {
        $recentReply = array();
        switch ($thread['recentReply']) { # 'recentReply00' is the latest reply, and it will be pushed last.
            case 20: if ($thread['recentReply19'] > 0) $recentReply[] = $thread['recentReply19'];
            case 19: if ($thread['recentReply18'] > 0) $recentReply[] = $thread['recentReply18'];
            case 18: if ($thread['recentReply17'] > 0) $recentReply[] = $thread['recentReply17'];
            case 17: if ($thread['recentReply16'] > 0) $recentReply[] = $thread['recentReply16'];
            case 16: if ($thread['recentReply15'] > 0) $recentReply[] = $thread['recentReply15'];
            case 15: if ($thread['recentReply14'] > 0) $recentReply[] = $thread['recentReply14'];
            case 14: if ($thread['recentReply13'] > 0) $recentReply[] = $thread['recentReply13'];
            case 13: if ($thread['recentReply12'] > 0) $recentReply[] = $thread['recentReply12'];
            case 12: if ($thread['recentReply11'] > 0) $recentReply[] = $thread['recentReply11'];
            case 11: if ($thread['recentReply10'] > 0) $recentReply[] = $thread['recentReply10'];
            case 10: if ($thread['recentReply09'] > 0) $recentReply[] = $thread['recentReply09'];
            case 9:  if ($thread['recentReply08'] > 0) $recentReply[] = $thread['recentReply08'];
            case 8:  if ($thread['recentReply07'] > 0) $recentReply[] = $thread['recentReply07'];
            case 7:  if ($thread['recentReply06'] > 0) $recentReply[] = $thread['recentReply06'];
            case 6:  if ($thread['recentReply05'] > 0) $recentReply[] = $thread['recentReply05'];
            case 5:  if ($thread['recentReply04'] > 0) $recentReply[] = $thread['recentReply04'];
            case 4:  if ($thread['recentReply03'] > 0) $recentReply[] = $thread['recentReply03'];
            case 3:  if ($thread['recentReply02'] > 0) $recentReply[] = $thread['recentReply02'];
            case 2:  if ($thread['recentReply01'] > 0) $recentReply[] = $thread['recentReply01'];
            case 1:  if ($thread['recentReply00'] > 0) $recentReply[] = $thread['recentReply00'];
            case 0; # do nothing
        }
        $thread['pwd'] = '';
        foreach ($thread as $key => $value) { # not byRef
            if (stripos($key, 'recentReply') !== false) unset($thread[$key]);
            unset($key, $value);
        }
        $thread['recentReply']  = $recentReply;
        if(0 === $thread['delete']) $THREADS[$thread['id']] = $thread;
        $replyIndex = array_merge($replyIndex, $recentReply); # "+" will merge numeric keys. array_merge() will not.
        unset($thread, $recentReply);
    }
    unset($sth); # $REPLY_INDEX, $THREADS will survive.
# REPLIES
    if (!empty($replyIndex)) { # No result is okey even without `delete` = 0.
        $replyIndex = implode(', ', $replyIndex);
        # [ORDER BY `createdAt`] or [ORDER BY field(id,{$replyIndex})] does hardly any good.
        $sth = $pdo->query("SELECT * FROM `{$TABLE_NAME}` WHERE `id` IN ({$replyIndex});");
        if (false === $sth)             throw new Exception(FAILURE::REPLY_SELECT, -1);
        while ($reply = $sth->fetch()) {
            foreach ($reply as $key => $value) { # not byRef
                if (stripos($key, 'recentReply') !== false) unset($reply[$key]);
                unset($key, $value);
            }
            $reply['pwd'] = '';
            if(0 === $reply['delete']) $REPLIES[$reply['id']] = $reply;
            unset($reply);
        }
        unset($sth); # $REPLIES will survive.
    }
    unset($replyIndex);
# OUTPUT
    if (isset($_REQUEST['callback'])) {
        $json_str = enjson(array(
            'info' => $INFO,
            'threads' => $THREADS,
            'replies' => $REPLIES
        ));
        $callback = preg_replace('/[^\w\$]/', '', $_REQUEST['callback']);
        echo "/**/ typeof {$callback} === \'function\' && {$callback}({$json_str})";
        exit;
    } elseif (isset($_REQUEST['json'])) {
        $json_str = enjson(array(
            'info' => $INFO,
            'threads' => $THREADS,
            'replies' => $REPLIES
        ));
        echo $json_str;
        exit;
    } else {
        require './tpl/head.php';
        foreach ($THREADS as $TID => $THREAD) { //$thread is refreshed
            require './tpl/post.php';
            foreach ($THREAD['recentReply'] as $RID) {
                $REPLY = $REPLIES[$RID];
                require './tpl/reply.php';
                unset($REPLY, $RID);
            }
            unset($TID, $THREAD);
        }
        require './tpl/tail.php';
        exit;
    }
}
catch (PDOException $pdoException) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code']    = $pdoException->getCode();
    $done['line']    = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
    require './tpl/done.php';
    exit;
}
catch (Exception $Exception) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
# DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code']    = $Exception->getCode();
    $done['line']    = $Exception->getLine();
    $done['message'] = $Exception->getMessage();
    require './tpl/done.php';
    exit;
}
throw new Exception('Unexpected Error.');
# foreach will iterate in the order it is first pushed into array, e.g.: 
    # $arr = array(4 => 'sss',3 => 'xxx', 5 => 'aaa');foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa
    # $arr[3] = 'xxxx';foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa4sss3xxxx5aaa

# ABOUT LIMIT OFFSET - MSYQL, PQSQL, SQLITE SUPPORT THIS GRAMMAR
#   http://stackoverflow.com/questions/971964/limit-10-20-in-sql-server
#   http://blogs.msdn.com/b/sqlserver/archive/2006/10/25/limit-in-sql-server.aspx
# HOWEVER, MOST DATABASE SUPPORT SIMILAR QUERY DIFFERNTLY
# PDO_CUBRID   cubrid:    Cubrid
# PDO_DBLIB    sybase:    Sybase
#              mssql:     Microsoft SQL Serve
#              dblib:     FreeTDS
# PDO_FIREBIRD firebird:  Firebird/Interbase 6
# PDO_IBM      ibm:       IBM DB2
# PDO_INFORMIX informix:  IBM Informix Dynamic Server
# PDO_MYSQL    mysql:     MySQL 3.x/4.x/5.x
# PDO_SQLSRV   sqlsrv:    Microsoft SQL Server / SQL Azure
# PDO_OCI      oci:       Oracle Call Interface
# PDO_ODBC     odbc:      ODBC v3 (IBM DB2, unixODBC and win32 ODBC)
# PDO_PGSQL    pgsql:     PostgreSQL
# PDO_SQLITE   sqlite:    SQLite 3 & SQLite 2
# PDO_4D       4D:        4D
#   http://www.jooq.org/doc/3.5/manual/sql-building/sql-statements/select-statement/limit-clause/
# FOR THIS VERSION I WILL ONLY SUPPORT MYSQL-ALIKE GRAMMER.

