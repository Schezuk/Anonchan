<?php
class INVALID {
    const ID
    const PWD
}
class FAILURE {       
    const PREPARE
    const TRANSACTION
    const TRANSACTION
    const EXECUTE
    const UPDATE
    const ROWCOUNT
    const COMMIT

}
class DONE
{
    const SUCCESS   = ;
    const SUCCEED   = ;
    const FAILURE   = ;
    const FAILED    = ;
    const REQUEST   = ;
    const ERRORCODE = ;
    const ERRORLINE = ;
    const MESSAGE   = ;
}
class SHOW
{
    
}






















/* TEMPLATE LANGUAGE */                                                                          
// templet head & header */                                                                      
$__forum_title = '综合';// This is the channel's name.                                           
$__board_title='匿名版';// This is the name of the name of the site / the channel-group it joins.
$__messages    = array(	// This is the messages for sakura IME.                                  
'在没有附加图片的情况下，请写入内容',                                                            
'附加图片为系统不支持的格式',                                                                    
'侦测到您有输入樱花日文假名的可能性，将自动为您转换'                                             
);			// Default messages above.                                                           
$__return_home='回首页';// Go back first page of forum.                                          
$__refresh    =  '刷新';// Refresh this page.                                                    
                                                                                                 
/* templet newpost & delpost */                                                                  
// To change emoji, you have to edit templet newpost.                                            
$__post_name	= '名　称';                                                                      
$__post_submit	= '送　出';                                                                      
$__post_email	= '电　邮';                                                                      
$__post_title	= '标　题';                                                                      
$__post_emoji	= '颜文字';                                                                      
$__post_content	= '内　文';                                                                      
$__post_image	= '外链图';                                                                      
$__post_pwd	= '删文码';                                                                          
$__post_pwdexp	= '(删除文章用,8位以内英文/数字密码)';                                           
$__post_noscript= '＊您选择关闭了JavaScript，但这对您的浏览及发文应无巨大影响。';                
$__post_coolDown= '本版发帖冷却时间秒数为：';                                                    
                                                                                                 
$__delete_post	= '【删除文章】';                                                                
$__post_reply_id= '文章/回复ID';                                                                 
$__pwd_to_delete= '删除用密码：';                                                                
$__onlyimgdel	= '仅删除附加图片';                                                              
$__del_execute	= ' 执行 ';                                                                      
// I AM LAZY. :)                                                                                 
                                                                                                 
/* templet op & reply*/                                                                          
$__no_title = '无标题';	// When title is empty.                                                  
$__no_name  = '无名氏';	// When name is empty.                                                   
$__omission = '该帖有 #### 篇回复被省略。要查看所有回复请点击回应链接。';                        
			// "####" will be replaced with the count of omitted replies.                        
$__like     = '该帖有 #### 人好评！';                                                            
$__dislike  = '该帖有 #### 人差评！';                                                            
$__show_liker	= 1;	// 1 means true.                                                         
$__show_disliker= 1;	// 1 means true.                                                         
$__show_them	= '他们是：';                                                                    
$__reply    = '[回复]';                                                                          
$__isHidden = '该文已折叠，请点击显示。';                                                        
$__hide_rate= 1;                                                                                 
$__hide_diff= 5;                                                                                 
//rating function: hide = 1 when newdislike > newlike * hide_rate + hide_diff                    
/* templet tail */                                                                               
$__first_page = '首页'; // First page of forum.                                                  
$__last_page  = '末页'; // Last page of forum.                                                   
                                                                                                
/* api delete */                                                                                 
$delete_goto		= &$referer;                                                                 
$delete_timeout		= 5;                                                                         
$delete_failed		= '删除失败！5秒钟后返回原页面。';                                           
$delete_succeeded	= '删除成功！5秒钟后返回原页面。';                                           
                                                                                                 
/* api post*/                                                                                    
$post_goto		= 'forum.php?page=1';                                                            
$post_timeout		= 5;                                                                         
$post_image_not_valid	= '链接不正确！5秒钟后返回首页。';                                       
$post_coolDown		= '发帖太快了！5秒钟后返回首页。';                                           
$post_parent_not_exist	= '该贴不存在！5秒钟后返回首页。';                                       
$post_parent_deleted	= '该贴已删除！5秒钟后返回首页。';                                       
$post_parent_locked	= '该贴已锁定！5秒钟后返回首页。';                                           
$post_newpost_failed	= '发帖有错误！5秒钟后返回首页。';                                       
$post_update_failed	= '未关联贴主！5秒钟后返回首页。';                                           
$post_succeeded		= '回复已成功！5秒钟后返回首页。';                                           
                                                                                                 
/* api like */                                                                                   
$like_goto		= &$referer;                                                                     
$like_timeout		= 5;                                                                         
$like_failed		= '好评失败！5秒钟后返回原页面。';                                           
$like_succeeded		= '好评成功！5秒钟后返回原页面。';                                           
                                                                                                 
/* api dislike */                                                                                
$dislike_goto		= &$referer;                                                                 
$dislike_timeout	= 5;                                                                         
$dislike_failed		= '差评失败！5秒钟后返回原页面。';                                           
$dislike_succeeded	= '差评成功！5秒钟后返回原页面。';                                           
                                                                                                 
/* api thread */                                                                                 
$thread_timeout		= 'forum.php?page=1';                                                        
$thread_goto		= 5;                                                                         
$thread_not_exist	= '版面错误！5秒钟后返回首页。';                                             
$thread_deleted		= '版面删除！5秒钟后返回首页。';                                             
                                                                                                 
/* api forum */                                                                                  
$forum_timeout		= 'forum.php?page=1';                                                        
$forum_goto		= 5;                                                                             
$forum_not_exist	= '版面错误！5秒钟后返回首页。';                                             
$forum_deleted		= '版面删除！5秒钟后返回首页。';                                             
                                                                                                 
                                                                                                 
