<?php
class MESSAGE {
    const HTML          = 0;
    const JSON          = 1;
    const CALLBACK      = 2;
    const JSON_CALLBACK = 3;

    public $success;
    public $message;
    public $request;
    public $code;
    public $line;

    public $style;
    public $json;
    public $callback;

    private $title;
    private 
    private 
    private 
    
    
    
    public function __construct($success = false, $message = '', $request = '', $code = 0, $line = 0) {
        $this->success  = $success;
        $this->message  = $message;
        $this->request  = $request;
        $this->code     = $code;
        $this->line     = $line;
        
        $this->getStyle();
        $this->getTitle();
        $this->getCallback();
        $this->getJson();
    }
    protected function getStyle() {
        if     (isset($_REQUEST['callback'])) $this->style = self::JSON | self::CALLBACK;
        elseif (isset($_REQUEST['json']))     $this->style = self::JSON;
        else                                  $this->style = 0;
    }
    protected function getTitle(){
        if ($this->success === true) $this->title = $this->request . ;
        else $this->title = $this->request . 
    }
    protected function getCallback() {
        $this->callback = preg_replace('/[^\w\$]/', '', $_REQUEST['callback']);
    }
    protected function getJson() {
        $this->json = enjson(array( 'success' =>  $this->success;
                                    'request' =>  $this->request;
                                    'code'    =>  $this->code;
                                    'line'    =>  $this->line;
                                    'message' =>  $this->message;
                                    ));
    }
    public function show() {
        if      (($this->style & self::CALLBACK) > 0) echo "/**/ typeof {$this->callback} === \'function\' && {$this->callback}({$this->json})";
        elseif  (($this->style & self::JSON)     > 0) echo $this->json;
        else  {        }
    }