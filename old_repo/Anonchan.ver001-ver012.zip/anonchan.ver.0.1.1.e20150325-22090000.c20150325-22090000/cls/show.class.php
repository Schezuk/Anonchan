<?php
if (isset($_REQUEST['callback'])) {
    $callback = preg_replace('/[^\w\$]/', '', $_REQUEST['callback']);
    $json_str = enjson($done);
    echo "/**/ typeof {$callback} === \'function\' && {$callback}({$json_str})";
    exit;
} elseif (isset($_REQUEST['json'])) {
    $json_str = enjson($done);
    echo $json_str;
    exit;
} else {
    header('Access-Control-Allow-Origin: *'); 
    header('Cache-Control: no-store, no-cache, must-revalidate');  
    header('Cache-Control: post-check=0, pre-check=0', false);  
    header('Pragma: no-cache');
    if (isset($_SERVER['HTTP_REFERER'])){
        header('refresh:' . $REFRESH_DURATION . ';url=' . $_SERVER['HTTP_REFERER']);
    } else {
        header('refresh:' . $REFRESH_DURATION . ';url=' . './forum.php');
    }
?>


