<?php
# Even private properties will be fetched into object.
# According to http://stackoverflow.com/questions/7282962/
class NODE {
	# Public Properties.
	public $id;
	public $parent;
	public $updatedAt;
	public $createdAt;
	public $replyCount;
	public $uid;
	public $name;
	public $email;
	public $title;
	public $image;
	public $content;
	public $hide;
	public $sage;
	public $lock;
	public $delete;
	public $like;
	public $liker;
	public $dislike;
	public $disliker;
	public $recentReply; # Not in Database

	# Protected Properties
	protected $pwd;
	protected $recentReply00;
	protected $recentReply01;
	protected $recentReply02;
	protected $recentReply03;
	protected $recentReply04;
	protected $recentReply05;
	protected $recentReply06;
	protected $recentReply07;
	protected $recentReply08;
	protected $recentReply09;
	protected $recentReply10;
	protected $recentReply11;
	protected $recentReply12;
	protected $recentReply13;
	protected $recentReply14;
	protected $recentReply15;
	protected $recentReply16;
	protected $recentReply17;
	protected $recentReply18;
	protected $recentReply19;
	protected $date; # Not in Database
	protected $uid_base64;
	protected $qlink;
	protected $templetUrl = 'tpl/reply.tpl.php'; # Not in Database
	
	# Methods

	public function __construct() {
		$this->initName();
		$this->initTitle();
		$this->initDate();
		$this->initUid();
		$this->initQlink();
		$this->initLiker();
		$this->initDisliker();
		$this->initRecentReply();
		$this->templetUrl = ROOT_PATH . $this->templetUrl;
	}
	public function checkPwd() {
		$request = array_change_key_case($_REQUEST);
		if (isset($request['pwd'] && $request['pwd'] = $pwd)) return true;
		else return false;
	}
	public function showHtml() {
		$lang = new LANG();
		echo require $templetUrl;
	}
	protected function initName() {
		if ($this->name === '') $this->name = LANG::NO_NAME;
	}
	protected function initTitle() {
		if ($this->title === '') $this->title = LANG::NO_TITLE;
	}
	protected function initDate() {
		$this->date = date('Y-m-d H:i:s', $this->createdAt);
	}
	protected function initUid() {
		$this->uid_base64 = base64_encode($this->uid);
	}
	protected function initQlink() {
		$this->qlink = "javascript:quote('{$this->id}')";
		#$this->qlink = "./thread.php?id={$this->parent}'#'{$this->id}";
	}
	
	protected function initLiker() {
		if (is_int(INIT::SHOW_LIKER))) {
			if (INIT::SHOW_LIKER < -1) {
				$this->$liker = '';
				$this->$like = 0;
			} elseif (INIT::SHOW_LIKER = 0) {
				$this->$liker = '';
			} else (INIT::SHOW_LIKER * INIT::LEN_UID_RAW < LEN_LIKER) {
				substr($this->$liker,0 , INIT::SHOW_LIKER * INIT::LEN_UID_RAW);
			}
		}
	}
	protected function initDisliker() {
		if (is_int(INIT::SHOW_DISLIKER))) {
			if (INIT::SHOW_DISLIKER < -1) {
				$this->$disliker = '';
				$this->$dislike = 0;
			} elseif (INIT::SHOW_DISLIKER = 0) {
				$this->$disliker = '';
			} else (INIT::SHOW_DISLIKER * INIT::LEN_UID_RAW < LEN_DISLIKER) {
				substr($this->$disliker,0 , INIT::SHOW_DISLIKER * INIT::LEN_UID_RAW);
			}
		}
	}
	protected function initRecentReply() {
		if ($thread['recentReply19'] > 0) $this->recentReply[] = $recentReply19;
		if ($thread['recentReply18'] > 0) $this->recentReply[] = $recentReply18;
		if ($thread['recentReply17'] > 0) $this->recentReply[] = $recentReply17;
		if ($thread['recentReply16'] > 0) $this->recentReply[] = $recentReply16;
		if ($thread['recentReply15'] > 0) $this->recentReply[] = $recentReply15;
		if ($thread['recentReply14'] > 0) $this->recentReply[] = $recentReply14;
		if ($thread['recentReply13'] > 0) $this->recentReply[] = $recentReply13;
		if ($thread['recentReply12'] > 0) $this->recentReply[] = $recentReply12;
		if ($thread['recentReply11'] > 0) $this->recentReply[] = $recentReply11;
		if ($thread['recentReply10'] > 0) $this->recentReply[] = $recentReply10;
		if ($thread['recentReply09'] > 0) $this->recentReply[] = $recentReply09;
		if ($thread['recentReply08'] > 0) $this->recentReply[] = $recentReply08;
		if ($thread['recentReply07'] > 0) $this->recentReply[] = $recentReply07;
		if ($thread['recentReply06'] > 0) $this->recentReply[] = $recentReply06;
		if ($thread['recentReply05'] > 0) $this->recentReply[] = $recentReply05;
		if ($thread['recentReply04'] > 0) $this->recentReply[] = $recentReply04;
		if ($thread['recentReply03'] > 0) $this->recentReply[] = $recentReply03;
		if ($thread['recentReply02'] > 0) $this->recentReply[] = $recentReply02;
		if ($thread['recentReply01'] > 0) $this->recentReply[] = $recentReply01;
		if ($thread['recentReply00'] > 0) $this->recentReply[] = $recentReply00;
	}
}