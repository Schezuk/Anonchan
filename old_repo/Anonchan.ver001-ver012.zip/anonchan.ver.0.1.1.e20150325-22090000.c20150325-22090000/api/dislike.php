<?php
# EXECUTE INIT
require './init.php';
# SQL
$sql = <<<SQL
UPDATE `{$TABLE_NAME}` 
SET `hide` = (CASE WHEN (`dislike` + 1) > (`like` * $HIDE_RATIO + $HIDE_DIVIATION) 
                   THEN 1 
                   ELSE 0
              END),
    `dislike`  = `dislike` + 1,
    `disliker` = LEFT(CONCAT(:UID, `disliker`), :LEN_DISLIKER)
WHERE `id` = :ID AND 0 =  CHARINDEX(:UID, `disliker`);
SQL;
# 'INSTR(`disliker`, :UID)' may err when collision, but works in most of times.
try {
    # UID
    $uid = getUid(UID_RAW);
    # ID
    $id = intval($_REQUEST['id']);
    if ($id < 1 or $id > MAX_THREAD_ID) throw new Exception(INVALID::ID, -1);
    # PDO
    $pdo = new PDO($dsn, $username, $password,$options);
    if (!$sth = $pdo->prepare($sql))    throw new Exception(FAILURE::PREPARE, -1);
    if (!$pdo->beginTransaction())      throw new Exception(FAILURE::TRANSACTION, -1);
    if (!$pdo->inTransaction())         throw new Exception(FAILURE::TRANSACTION, -1);
    # PARAM
    # PARAM
    $param[':ID']  = $id;
    $param[':UID'] = $id;
    $param[':LEN_LIKER'] = LEN_LIKER;
    if (!$sth->execute($param))         throw new Exception(FAILURE::EXECUTE, -1);
    # ROWCOUNT
    $rowCount = $sth->rowCount();
    if (0 === $rowCount)                throw new Exception(FAILURE::UPDATE, -1);
    if (2 <=  $rowCount)                throw new Exception(FAILURE::ROWCOUNT.$rowCount, -1);
    unset($rowCount);
    if (!$pdo->commit())                throw new Exception(FAILURE::COMMIT, -1);
    # DONE
    $done['success'] = true;
    $done['request'] = 'dislike';
    $done['code'   ] = 0;
    $done['line'   ] = 0;
    $done['message'] = $SUCCESS_TO_DISLIKE;
} catch (PDOException $pdoException){
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'dislike';
    $done['code'   ] = $pdoException->getCode();
    $done['line'   ] = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
} catch (Exception $Exception) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'dislike';
    $done['code'   ] = $Exception->getCode();
    $done['line'   ] = $Exception->getLine();
    $done['message'] = $Exception->getMessage();
}
# EXECUTE DONE 
require './tpl/done.php';
