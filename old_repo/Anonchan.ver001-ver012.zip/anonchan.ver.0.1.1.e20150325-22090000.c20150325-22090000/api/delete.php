<?php
# EXECUTE INIT
require './init.php';
if (isset($_REQUEST['onlyimgdel'])) 
     $sql = "UPDATE `{$TABLE_NAME}` SET `image` = '' WHERE `id` = :ID AND `pwd` = :PWD;";# Double Quote for $TABLE_NAME
else $sql = "UPDATE `{$TABLE_NAME}` SET `delete` = 1 WHERE `id` = :ID AND `pwd` = :PWD;";# Double Quote for $TABLE_NAME
try {
    # ID
    $id = intval($_REQUEST['id']);
    if ($id < 1 or $id > MAX_THREAD_ID) throw new Exception(INVALID::ID,-1);
    # PWD
    $pwd = substr($_REQUEST['pwd'],0,8);
    if ('' === $pwd)                    throw new Exception(INVALID::PWD,-1);
    # PDO
    $pdo = new PDO($dsn, $username, $password,$options);
    if (!$sth = $pdo->prepare($sql))    throw new Exception(FAILURE::PREPARE,            -1);
    if (!$pdo->beginTransaction())      throw new Exception(FAILURE::TRANSACTION,   -1);
    if (!$pdo->inTransaction())         throw new Exception(FAILURE::TRANSACTION,      -1);
    # PARAM
    $param[':ID']  = $id;
    $param[':PWD'] = $PWD;
    if (!$sth->execute($param))         throw new Exception(FAILURE::EXECUTE,            -1);
    # ROWCOUNT
    $rowCount = $sth->rowCount();
    if (0 === $rowCount)                throw new Exception(FAILURE::UPDATE,             -1);
    if (2 <=  $rowCount)                throw new Exception(FAILURE::ROWCOUNT.$rowCount, -1);
    unset($rowCount);
    if (!$pdo->commit())                throw new Exception(FAILURE::COMMIT,             -1);
    # DONE
    $done['success'] = true;
    $done['request'] = 'delete';
    $done['code'   ] = 0;
    $done['line'   ] = 0;
    $done['message'] = $SUCCESS_TO_DELETE;
} catch (PDOException $pdoException){
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'delete';
    $done['code'   ] = $pdoException->getCode();
    $done['line'   ] = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
} catch (Exception $Exception) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'delete';
    $done['code'   ] = $Exception->getCode();
    $done['line'   ] = $Exception->getLine();
    $done['message'] = $Exception->getMessage();
}
# EXECUTE DONE 
require './tpl/done.php';
exit;
