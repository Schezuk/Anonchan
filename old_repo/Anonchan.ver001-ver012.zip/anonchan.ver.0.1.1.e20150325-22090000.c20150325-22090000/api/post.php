<?php
try {
# EXECUTE INIT
require './init.php';
$sql = <<<SQL
INSERT INTO `{$TABLE_NAME}` (
    `parent`, `updatedAt`, `createdAt`, `replyCount`, 
    `uid`, `name`, `email`, `title`, `image`, `content`, 
    `hide`, `sage`, `lock`, `deleted`, `pwd`, `like`, `liker`, `dislike`, `disliker`, 
    `recentReply00`, `recentReply01`, `recentReply02`, `recentReply03`, `recentReply04`, 
    `recentReply05`, `recentReply06`, `recentReply07`, `recentReply08`, `recentReply09`, 
    `recentReply10`, `recentReply11`, `recentReply12`, `recentReply13`, `recentReply14`, 
    `recentReply15`, `recentReply16`, `recentReply17`, `recentReply18`, `recentReply19`
) VALUES (
    :parent, :updatedAt, :createdAt, 0,
    :uid, :name, :email, :title, :image, :content, 
    0, :sage, 0, 0, :pwd, 0, "", 0, "", 
    0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0 
);
SQL;
$sql2 = <<<SQL
UPDATE `{$TABLE_NAME}` SET 
    `updatedAt`  = :updatedAt, `replyCount` = `replyCount` + 1,
    `recentReply19` = `recentReply18`, 
    `recentReply18` = `recentReply17`, 
    `recentReply17` = `recentReply16`, 
    `recentReply16` = `recentReply15`, 
    `recentReply15` = `recentReply14`, 
    `recentReply14` = `recentReply13`, 
    `recentReply13` = `recentReply12`, 
    `recentReply12` = `recentReply11`, 
    `recentReply11` = `recentReply10`, 
    `recentReply10` = `recentReply09`, 
    `recentReply09` = `recentReply08`, 
    `recentReply08` = `recentReply07`, 
    `recentReply07` = `recentReply06`, 
    `recentReply06` = `recentReply05`, 
    `recentReply05` = `recentReply04`, 
    `recentReply04` = `recentReply03`, 
    `recentReply03` = `recentReply02`, 
    `recentReply02` = `recentReply01`, 
    `recentReply01` = `recentReply00`, 
    `recentReply00` = :recentReply
WHERE `id` = :parent;
SQL;
    # Swapping columns works differently in MySQL, PqSQL and SQLserver.
        # http://stackoverflow.com/questions/37649/
        # http://beerpla.net/2009/02/17/swapping-column-values-in-mysql/
        # http://stackoverflow.com/questions/4198587/
    # However, it doesn't matter much with shifting.
        # http://www.sqlservercentral.com/Forums/Topic1496024-3077-1.aspx
    # PARAM ====================================================================
    $post[':parent']    = intrange($_POST['id'], 0, MAX_THREAD_ID);
    $post[':updatedAt'] = time();
    $post[':createdAt'] = $post[':updatedAt'];
    $post[':uid']       = getUid(UID_RAW);
    $post[':name']      = substr(htmlspecialchars($_POST['name'], ENT_NOQUOTES, 'UTF-8'),0,LEN_NAME);
    $post[':email']     = substr(htmlspecialchars($_POST['email'], ENT_NOQUOTES, 'UTF-8'),0,LEN_EMAIL);
    $post[':title']     = substr(htmlspecialchars($_POST['title'], ENT_NOQUOTES, 'UTF-8'),0,LEN_TITLE);
    $post[':image']     = substr(htmlspecialchars($_POST['image'], ENT_NOQUOTES, 'UTF-8'),0,LEN_IMAGE);
    $post[':content']   = nl2br(substr(htmlspecialchars($_POST['content'], ENT_NOQUOTES, 'UTF-8'),0,LEN_CONTENT));
    $post[':sage']      = strcasecmp($post[':email'],'sage')? 1 : 0;
    $post[':pwd']       = substr($_POST['pwd'],0,LEN_PWD);
    # VALIDATE IMAGE ===========================================================
        # 'get_headers()' won't work, because sinaimg.cn has no 'Content-Type:' in Response Headers.
        # 'img src' is not very XSS vulnerable. See https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet
    $regexp = '/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i';
    if (!preg_match($regexp,$image) or stristr($image,'javascript'))
                                        throw new Exception($INVALID_IMAGE_URL,             -1);
    # PDO ======================================================================
    $pdo = new PDO($dsn, $username, $password,$options);
    # INFO =====================================================================
    $sth = $pdo->query("SELECT `lock`, `delete`, `content` FROM `{$TABLE_NAME}` where `id` = 0;"); 
    # Double Quote for $TABLE_NAME
    if (false === $sth)                 throw new Exception($FAILURE_SELECT_INFO,        -1);
        # `hide`, `sage` is not relevant. INC `lock`/`delete` of root will lock/lock and delete the whole forum.
    $INFO = $sth->fetch();
    if (false === $sth->closeCursor())  throw new Exception($FAILURE_CLOSE_CURSOR,       -1);
    if (false === $INFO)                throw new Exception($FAILURE_FETCH_INFO,         -1);
    if ($INFO['lock']   > 0)            throw new Exception($LOCKING_INFO,                  -1);
    if ($INFO['delete'] > 0)            throw new Exception($DELETED_INFO,                  -1);
    # HISTORY ==================================================================
    if (stripos($INFO['content'],$post[':uid'] !== false)) {
        foreach (str_split($INFO['content'], LEN_UID_RAW + LEN_TIMESTAMP) as $history) {
            if ($post[':updatedAt'] > $COOL_DOWN + unpack('N', substr($history, LEN_UID_RAW, LEN_TIMESTAMP)))
                break;
            if ($post[':uid'] === substr($history, 0, LEN_UID_RAW))
                                        throw new Exception($COOLING_DOWN,                  -1);
        }
    } unset($sth, $history); # $INFO will survive.
    # PARENT ===================================================================
    for ($i = 0;; $i++) {
        if(2 === $i)                    throw new Exception($FAILURE_REACH_INFO,         -1);
        $sth = $pdo->query("SELECT * FROM `{$TABLE_NAME}` WHERE `id` = {$post[':parent']}");
        if (false === $sth)             throw new Exception($FAILURE_SELECT_INFO, -1);
        # To make sure $post is the final $post, the best way is to edit and test it live.
        if (false ===($PARENT = $sth->fetch()))
                                        throw new Exception($FAILURE_FETCH_PARENT,  -1);
        if (false===$sth->closeCursor())throw new Exception($FAILURE_CLOSE_CURSOR,       -1);
        if (0 === $post[':parent'] || 0 === $PARENT['parent']) break;   # If create a new thread or reply to threads.
        else $post[':parent'] = $PARENT['parent'];                      # If reply to replies, redirect to parent thread.
    } unset($sth); # $PARENT will survive.
    if ($PARENT['lock']   > 0)      throw new Exception($LOCKING_PARENT,                -1);
    if ($PARENT['delete'] > 0)      throw new Exception($DELETED_PARENT,                -1);
    # Replying to a locking or deleted reply will redirect you to parent thread as well.
    # POST =====================================================================
    if (!$sth = $pdo->prepare($sql))    throw new Exception($FAILURE_PREPARE,            -1);
    if (!$pdo->beginTransaction())      throw new Exception($FAILURE_BEGINTRANSACTION,   -1);
    if (!$pdo->inTransaction())         throw new Exception($FAILURE_INTRANSACTION,      -1);
    if (!$sth->execute($post))          throw new Exception($FAILURE_EXECUTE,            -1);
    # ROWCOUNT =================================================================
    $rowCount = $sth->rowCount();
    if (0 === $rowCount)                throw new Exception($FAILURE_INSERT,             -1);
    if (2 <=  $rowCount)                throw new Exception($UNEXPECTED_ROWCOUNT.$rowCount, -1);
    unset($rowCount);
    # UPDATE ===================================================================
        # If creating new thread, the root will be updated.
        # If replying to threads, the thread will be updated.
    $LAST_INSERT_ID = $pdo->lastInsertId();
    if ($PARENT['recentReply00'] > $pdo->lastInsertId()) {
                                        throw new Exception($INVALID_ID,                    -1);
    } else {
        $UPDATE[':recentReply'] = $pdo->lastInsertId();
        $UPDATE[':parent']      = $post[':parent'];
        $UPDATE[':updatedAt']   = (0 === $post[':sage']) ? $post[':updatedAt'] : $PARENT['updateAt'];
    }
    if (!$sth = $pdo->prepare($sql2))   throw new Exception($FAILURE_PREPARE,            -1);
    if (!$sth->execute($UPDATE))        throw new Exception($FAILURE_EXECUTE,            -1);
    # ROWCOUNT =================================================================
    $rowCount = $sth->rowCount();
    if (0 === $rowCount)                throw new Exception($FAILURE_INSERT,             -1);
    if (2 <=  $rowCount)                throw new Exception($UNEXPECTED_ROWCOUNT.$rowCount, -1);
    unset($rowCount);
    # UPDATE ===================================================================
    $content = array(':content' => substr($post[':uid'] . pack('N', $post[':updatedAt']), 0, LEN_RECORD));
    if (!$sth = $pdo->prepare("UPDATE `{$TABLE_NAME}` SET `content` = :content WHERE `id` = 0;"))
                                        throw new Exception($FAILURE_PREPARE,            -1);
    if (!$sth->execute($UPDATE))        throw new Exception($FAILURE_EXECUTE,            -1);
    # ROWCOUNT =================================================================
    $rowCount = $sth->rowCount();
    if (0 === $rowCount)                throw new Exception($FAILURE_INSERT,             -1);
    if (2 <=  $rowCount)                throw new Exception($UNEXPECTED_ROWCOUNT.$rowCount, -1);
    # COMMIT ===================================================================
    if (!$pdo->commit())                throw new Exception($FAILURE_COMMIT,             -1);
    # DONE =====================================================================
    $done['success'] = true;
    $done['request'] = 'like';
    $done['code'   ] = 0;
    $done['line'   ] = 0;
    $done['message'] = $SUCCESS_TO_LIKE;
} catch (PDOException $pdoException){
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code'   ] = $pdoException->getCode();
    $done['line'   ] = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
} catch (Exception $Exception) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code'   ] = $Exception->getCode();
    $done['line'   ] = $Exception->getLine();
    $done['message'] = $Exception->getMessage();
}
# EXECUTE DONE 
require './tpl/done.php';
