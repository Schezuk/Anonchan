<?php
try {
# INIT
    require './init.php';
    $pdo = new PDO($dsn, $username, $password, $options);
    $INFO               = array();
    $THREAD             = array();
    $REPLY              = array();
    $THREADS            = array();
    $REPLIES            = array();
# INFO/THREAD
    $INFO['type']       = 'thread';
    $INFO['id']         = intrange($_POST['id'], 1, MAX_THREAD_ID); # Thread 0 and below will be converted to 1.
    $INFO['url']        = "./thread.php?id={$INFO['id']}&";
    $INFO['title']      = "No.{$INFO['id']} @ {$FORUM_NAME} - {$BOARD_NAME}";
    for ($i = 0;; $i++) {
        if(2 === $i)                        throw new Exception($FAILURE_ROOT_REACH,  -1);
        $sth = $pdo->query("SELECT * FROM `{$TABLE_NAME}` WHERE `id` = {$INFO['id']}");# the best way is to edit and test it live.
        if (false === $sth)                 throw new Exception($FAILURE_PARENT_SELECT, -1);
        if (false ===($ret = $sth->fetch()))throw new Exception($FAILURE_PARENT_FETCH,  -1);
        if (false === $sth->closeCursor())  throw new Exception($FAILURE_PARENT_CLOSECURSOR,-1);
        if (0 === $ret['parent']) break;    # If reply to threads.
        else $INFO['id'] = $ret['parent'];  # If reply to replies, redirect to parent thread.
    }
    unset($sth); # $THREAD will survive.
    if ($ret['delete'] > 0)             throw new Exception($DELETED_THREAD, -1);
    $INFO['lock']       = $ret['lock'];
    $INFO['delete']     = $ret['delete'];
    $INFO['replyCount'] = $ret['replyCount'];
    $INFO['size']       = ceil($INFO['replyCount'] / $THREADS_PER_PAGE);
    $INFO['page']       = intrange($_REQUEST['page'], 1, $INFO['size']); //page 0 is not accessable.
    $THREAD = $ret;
    $THREAD['pwd'] = '';
    foreach ($THREAD as $key => $value){ # not byRef
        if (stripos($key, 'recentReply') !== false) unset($THREAD[$key]);
        unset($key, $value);
    }
    unset($ret);
# REPLIES
    $sth = $pdo->prepare("SELECT * FROM `{$TABLE_NAME}` WHERE `parent` = :parent ORDER BY `updatedAt` ASC LIMIT :limit OFFSET :offset;");
    if (!$sth->execute(array(':parent'  =>  $TID,
                             ':limit'   =>  $THREADS_PER_PAGE * ($INFO['page'] - 1),
                             ':offset'  =>  $THREADS_PER_PAGE
                             )))        throw new Exception($FAILURE_EXECUTE,            -1);
    while ($reply = $sth->fetch()) {
        foreach ($reply as $key => $value){ # not byRef
            if (stripos($key, 'recentReply') !== false) unset($reply[$key]);
            unset($key, $value);
        }
        $reply['pwd'] = '';
        if(0 === $reply['delete']) $REPLIES[$reply['id']] = $reply;
        unset($reply);
    }
    unset($sth); # $REPLIES will survive.
# OUTPUT
    if (isset($_REQUEST['callback'])) {
        $json_str = enjson(array(
            'info' => $INFO,
            'thread' => $THREAD,
            'replies' => $REPLIES
        ));
        $callback = preg_replace('/[^\w\$]/','',$_REQUEST['callback']);
        echo "/**/ typeof {$callback} === \'function\' && {$callback}({$json_str})";
        exit;
    } elseif (isset($_REQUEST['json'])) {
        $json_str = enjson(array(
            'info' => $INFO,
            'thread' => $THREAD,
            'replies' => $REPLIES
        ));
        echo $json_str;
        exit;
    } else {
        require './tpl/head.php';
        require './tpl/post.php';
        foreach ($REPLIES as $RID=>$REPLY){
            require './tpl/reply.php';
            unset($REPLY, $RID);
        }
        require './tpl/tail.php';
        exit;
    }
} catch (PDOException $pdoException){
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code'   ] = $pdoException->getCode();
    $done['line'   ] = $pdoException->getLine();
    $done['message'] = $pdoException->getMessage();
    require './tpl/done.php';
    exit;
} catch (Exception $Exception) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollback();
    # DONE
    $done['success'] = false;
    $done['request'] = 'like';
    $done['code'   ] = $Exception->getCode();
    $done['line'   ] = $Exception->getLine();
    $done['message'] = $Exception->getMessage();
    require './tpl/done.php';
    exit;
}
throw new Exception('Unexpected Error.');
# foreach will iterate in the order it is first pushed into array, e.g.: 
    # $arr = array(4 => 'sss',3 => 'xxx', 5 => 'aaa');foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa
    # $arr[3] = 'xxxx';foreach ($arr as $key => $value) echo $key . $value;#4sss3xxx5aaa4sss3xxxx5aaa
