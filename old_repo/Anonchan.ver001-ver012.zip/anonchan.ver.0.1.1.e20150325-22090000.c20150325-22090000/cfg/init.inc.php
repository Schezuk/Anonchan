<?php
# Initialization File. Please save it in UNIX UTF-8(no BOM).
# Define Database Column Size.
class INIT extends CONFIG {
    const LEN_UID_RAW               =6; # LENGTH OF RAW UID
    const LEN_UID_BASE64            =8; # LENGTH OF UID AFTER BASE64 ENCODING
    const LEN_NAME                =255; # LENGTH OF NAME
    const LEN_EMAIL               =255; # LENGTH OF EMAIL
    const LEN_TITLE               =255; # LENGTH OF TITLE
    const LEN_IMAGE               =255; # LENGTH OF IMAGE
    const LEN_CONTENT            =2048; # LENGTH OF CONTENT
    const LEN_PWD                   =8; # LENGTH OF PWD
    const LEN_LIKER               =240; # LENGTH OF LIKER, LEN_UID_RAW * LIKER
    const LEN_DISLIKER            =240; # LENGTH OF DISLIKER, SIMILAR TO LIKER
    const LEN_RECORD             =2000; # LENGTH OF DISLIKER, SIMILAR TO LIKER
    const MAX_THREAD_ID    =2147483647; # MAXIMUM ID, PARENT OF THREAD 0
    const UID_RAW     =true;            # UID IS RAW DATA
    const UID_BASE64 =false;            # UID IS BASE64 ENCODED
    const LEN_TIMESTAMP = 4;            # LENGTH OF TIMESTAMP
    
    public $DSN;
    public $UID_RAW;
    public $UID_BASE64;
    public functino __construct() {
        $DSN  = self::DB_TYPE;
        $DSN .= ':dbname=' . self::DB_NAME;
        $DSN .= ';host='   . self::DB_HOST;
        $DSN .= ';port='   . strval(self::DB_PORT);
        $UID .= 
    }

           
    
# It should be compactable with 'config.sql'.
public function getUid($israw) {
    # Get dotted address string.
    $env[] = getenv('HTTP_CLIENT_IP');
    $env[] = getenv('HTTP_X_FORWARDED_FOR');
    $env[] = getenv('REMOTE_ADDR');
    if (isset($_SERVER['REMOTE_ADDR'])) {
        $env[] = $_SERVER['REMOTE_ADDR'];
    }
    # Check if valid and assign it to $onlineip.
    foreach ($env as $value) {
        if ($value && strcasecmp($value, 'unknown')) {
            $onlineip = '0.0.0.0';
        } else {
            $onlineip = $value;
            break;
        }
    }
    unset($value);
    # Proccess $onlineip into tripcode
    $onlineip = ip2long($onlineip);
    $onlineip = $onlineip & 0xEEEEEEEE;
    $onlineip = pack("H*", $onlineip);
    $onlineip = $onlineip . $TRIPCODE_SALT;
    $onlineip = sha1($onlineip, true); //20 byte raw string
    $onlineip = substr($onlineip, 0, self::LEN_UID_RAW);
    # MUST run substr before base64_encode
    if ($israw) {
        return $onlineip;
    } else {
        return base64_encode($onlineip);
    # MUST NOT run substr($onlineip, 0, self::LEN_UID_BASE64);
    }
}
public function intrange($value, $min, $max) {
    return min(max(intval($value),$min),max($min,$max));
}
public function enjson($arr) {
    if (version_compare(PHP_VERSION, '5.4.0', '>=')){
        return json_encode($arr, JSON_UNESCAPED_UNICODE);
    } else {
        return unescape_utf8(json_encode($arr));
    } # I haven't figure out how mb_decode_numericentity() works yet.
}
protected function unescape_utf8($str) {
    return str_replace('\\/', '/', preg_replace_callback(
           '/\\\\u([0-9a-fA-F]{4})/', 'unescape_utf8_callback', $str));
}
protected function unescape_utf8_callback($match) {
    return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
# ============================================================================
# Load Config File.
# ----------------------------------------------------------------------------
require_once './config.php';
# ============================================================================
# Database Configuration
# ----------------------------------------------------------------------------
if (!isset($dsn)) { # Yes, you can overwrite $dsn in 'config.php'.
    $dsn = $DB_TYPE;
    $dsn .= ':dbname=' . $DB_NAME;
    $dsn .= ';host=' . $DB_HOST;
    $dsn .= ';port=' . strval($DB_PORT);
}
$username = $DB_USER;
$password = $DB_PSWD;
$options = array(
    PDO::ATTR_CASE                    => PDO::CASE_NATURAL,
    PDO::ATTR_TIMEOUT                 => 10,
    PDO::ATTR_ERRMODE                 => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_ORACLE_NULLS            => PDO::NULL_TO_STRING,
    PDO::ATTR_DEFAULT_FETCH_MODE      => PDO::FETCH_ASSOC,
    PDO::MYSQL_ATTR_FOUND_ROWS        => TRUE,
    PDO::MYSQL_ATTR_INIT_COMMAND      => 'SET NAMES utf8',
    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY=> false
);
# ----------------------------------------------------------------------------
# $dsn, $username, $password will be used to construct PDO objects.
# ============================================================================
# Board Configuation
# ----------------------------------------------------------------------------
require './language.php';
if (isset($LANGUAGE))
    $LANGUAGE = strtolower($LANGUAGE);
else
    $LANGUAGE = 'zh-cn';
if (isset($LANGUAGE_CODE[$LANGUAGE]))
    require $LANGUAGE_CODE[$LANGUAGE];
else
    require './lang/zh-CN.php';
# ----------------------------------------------------------------------------
# It should be compactable with 'tpl/*.php'.
# ============================================================================
# Forum Configuation
# ----------------------------------------------------------------------------
$COOL_DOWN          = max(intval($COOL_DOWN),0);
$REFRESH_DURATION   = max(intval($REFRESH_DURATION),0);
$REPLIES_PER_PAGE   = max(intval($REPLIES_PER_PAGE),1);
$THREADS_PER_PAGE   = max(intval($THREADS_PER_PAGE),1);
$RECENT_REPLIES     = min(max(intval($RECENT_REPLIES),0),20);
foreach ($BLACK_LIST as &$value) {
    $value = substr($value, 0, LEN_UID_BASE64); # To make tripcode valid.
    # MUST run substr before base64_encode
    $value = base64_decode($value);
    # Must NOT run substr($value, 0, LEN_UID_RAW);
}
unset($value);
# ============================================================================
# THIS IS THE END OF THE INITIALIZATION FILE. DON'T ADD '?' AND '>' AT THE END.
###############################################################################