<?php
# TEMPLET thread.php #
return <<<EOT
<html>
<hr/>
<div class="threadpost" id="{$this->id}"> 
	<input type="checkbox" onclick="if (this.checked) $_('fid').value='{$this->id}'; else $_('fid').value='';" />
	<img src="{$this->image}" class='img' style='max-width:250px; max-height:250px' />
	<span class="title">{$this->title}</span>
	<span class="name" >{$this->name}</span>
	<span class="email" >{$this->email}</span>
	<span class="sage" style="color: #FF0000">{$this->contentSage}</span>
	<span class="time" >{$this->date}</span>
	<span class="uid">[ID:{$this->uid_base64}]</span>
    <a href="{$this->qlink}" class="qlink">No.{$this->id}</a>&nbsp;
    [<a href="{$this->qlink}" class="qlink">$lang->reply</a>]
	<br />
	<div style="{$this->styleHide};cursor:hand" onclick="isHidden('h{$this->id}')">{$lang->isHidden}</DIV>
	<div style="{$this->styleContent}" class="quote" id="h{$this->id}">{$this->content}</div>
    <div style="{$this->styleLike}" class="like">
        {$lang->prefixLike}{$this->contentLike}
        <div style="{$this->styleLiker}" class="liker">{$lang->prefixLiker}{$this->contentLiker}</div>
        <br />
    </div>
    <div style="{$this->styleDislike}" class="dislike">
        {$lang->prefixDislike}{$this->contentDislike}
        <div style="{$this->styleDisliker}" class="disliker">{$lang->prefixDisliker}{$this->contentDisliker}</div>
        <br />
    </div>
	<?php $omitted = $REPLY['replyCount'] - $RECENT_REPLIES;
	if ($omitted > 0) echo '<br/><span class="warn_txt2">' . str_replace('####',strval($omitted),$__omission) . '</span>'; ?>
</div>
EOT;
# END OF TEMPLET parent.php #
